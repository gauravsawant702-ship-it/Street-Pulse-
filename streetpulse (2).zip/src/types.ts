export type IssueCategory =
  | 'potholes'
  | 'water_leakages'
  | 'garbage_accumulation'
  | 'broken_streetlights'
  | 'damaged_infrastructure'
  | 'road_hazards';

export type IssueStatus =
  | 'Reported'
  | 'Under Verification'
  | 'Assigned'
  | 'In Progress'
  | 'Resolved';

export type SeverityLevel = 'Low' | 'Medium' | 'High' | 'Critical';

export interface UserProfile {
  id: string;
  email: string;
  name: string;
  role: 'citizen' | 'admin';
  points: number;
  reputationScore: number; // 0 to 100
  badges: string[]; // Badge IDs
  reportsCount: number;
  verificationsCount: number;
  createdAt: string;
  avatarUrl?: string;
}

export interface IssueTimelineEntry {
  status: IssueStatus;
  notes: string;
  updatedAt: string;
  updatedBy: string;
}

export interface Comment {
  id: string;
  issueId: string;
  userId: string;
  userName: string;
  avatarUrl?: string;
  text: string;
  createdAt: string;
  isOfficial: boolean;
}

export interface Verification {
  id: string;
  issueId: string;
  userId: string;
  userName: string;
  isUpvote: boolean; // true = positive verification, false = downvote/dispute
  createdAt: string;
}

export interface Issue {
  id: string;
  title: string;
  category: IssueCategory;
  description: string;
  imageUrl?: string;
  latitude: number;
  longitude: number;
  severity: SeverityLevel;
  suggestedAction: string;
  urgencyScore: number; // 1 to 100
  status: IssueStatus;
  reportedBy: string; // User ID
  reporterName: string;
  reporterAvatarUrl?: string;
  reportedAt: string;
  upvotes: number;
  verificationConfidence: number; // Percentage (e.g. 85%)
  duplicateOf?: string; // ID of another issue if duplicate
  comments: Comment[];
  verifications: Verification[];
  timeline: IssueTimelineEntry[];
}

export interface Notification {
  id: string;
  userId: string;
  title: string;
  text: string;
  type: 'status_update' | 'nearby_critical' | 'verification_request' | 'resolution_confirm';
  read: boolean;
  issueId?: string;
  createdAt: string;
}

export interface Badge {
  id: string;
  name: string;
  description: string;
  iconName: string; // Lucide icon identifier
  pointsRequired: number;
  color: string; // Tailwind color class
}

export interface CivicReport {
  id: string;
  issueId: string;
  title: string;
  generatedAt: string;
  generatedBy: string;
  summary: string;
  severityAnalysis: string;
  locationInfo: string;
  recommendedActionPlan: string;
}

export interface PredictiveHotspot {
  id: string;
  area: string;
  latitude: number;
  longitude: number;
  predictedCategory: IssueCategory;
  confidence: number; // 0 to 100
  riskReason: string;
  riskScore: number; // 1 to 100
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  timestamp: string;
}
