import React, { useState, useEffect, useRef } from "react";
import {
  Heart,
  Shield,
  Eye,
  Award,
  Zap,
  AlertTriangle,
  MapPin,
  CheckCircle2,
  MessageSquare,
  Plus,
  FileText,
  Send,
  User,
  ChevronRight,
  Check,
  X,
  Filter,
  Moon,
  Sun,
  Info,
  Calendar,
  AlertCircle,
  BarChart3,
  TrendingUp,
  Users,
  Download,
  HelpCircle,
  Loader2,
  Settings,
  Bell,
  CheckSquare,
  ArrowRight,
  Flame,
  Camera,
  Activity,
  PlusCircle,
  Trash2,
  Wrench,
  Menu,
  RefreshCw,
  Database,
  Save
} from "lucide-react";
import { Issue, IssueCategory, IssueStatus, UserProfile, Notification, PredictiveHotspot, Badge, CivicReport, ChatMessage } from "./types";

const BLANK_AVATAR = "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='%239ca3af'><path d='M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z'/></svg>";

const isVideoUrl = (url?: string) => {
  if (!url) return false;
  return url.startsWith("data:video/") || url.includes(".mp4") || url.includes(".mov") || url.includes(".webm") || url.includes(".avi") || url.includes(".mkv");
};

export default function App() {
  // Navigation & Theme
  const [activeTab, setActiveTab] = useState<"dashboard" | "report" | "explore" | "chatbot" | "leaderboard" | "admin">("dashboard");
  const [darkMode, setDarkMode] = useState<boolean>(false);
  const [user, setUser] = useState<UserProfile | null>(null);
  const [issues, setIssues] = useState<Issue[]>([]);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [predictive, setPredictive] = useState<{ hotspots: PredictiveHotspot[]; generalInsight: string; communityHealthScore: number } | null>(null);
  const [leaderboard, setLeaderboard] = useState<{ userId: string; name: string; avatar: string; points: number; badgeCount: number; reportsCount: number; reputation: number }[]>([]);
  const [badges, setBadges] = useState<Badge[]>([]);

  // Filters
  const [filterCategory, setFilterCategory] = useState<string>("all");
  const [filterStatus, setFilterStatus] = useState<string>("all");
  const [selectedIssue, setSelectedIssue] = useState<Issue | null>(null);

  // New Issue Form State
  const [formTitle, setFormTitle] = useState("");
  const [formCategory, setFormCategory] = useState<IssueCategory>("potholes");
  const [formDescription, setFormDescription] = useState("");
  const [formSeverity, setFormSeverity] = useState<"Low" | "Medium" | "High" | "Critical">("Medium");
  const [formLatitude, setFormLatitude] = useState<number>(37.7749);
  const [formLongitude, setFormLongitude] = useState<number>(-122.4194);
  const [formImage, setFormImage] = useState<string>("");
  const [analyzingImage, setAnalyzingImage] = useState(false);
  const [isSubmittingReport, setIsSubmittingReport] = useState(false);

  // Live Camera State
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [cameraDevices, setCameraDevices] = useState<MediaDeviceInfo[]>([]);
  const [selectedDeviceId, setSelectedDeviceId] = useState<string>("");
  const [cameraError, setCameraError] = useState<string>("");
  const videoStreamRef = useRef<MediaStream | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);

  useEffect(() => {
    return () => {
      if (videoStreamRef.current) {
        videoStreamRef.current.getTracks().forEach((track) => track.stop());
      }
    };
  }, []);

  // Comments & Verifications
  const [commentText, setCommentText] = useState("");
  const [isCastingVote, setIsCastingVote] = useState(false);

  // Chat State
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    {
      id: "init",
      sender: "ai",
      text: "Hello! I am **Pulse AI**, your smart civic assistant. Ask me anything about local community issues, check unresolved hazards, or generate standard reports for authorities.",
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    }
  ]);
  const [chatInput, setChatInput] = useState("");
  const [chatLoading, setChatLoading] = useState(false);

  // Report Document Modal State
  const [generatedReport, setGeneratedReport] = useState<CivicReport | null>(null);
  const [generatingReportId, setGeneratingReportId] = useState<string | null>(null);

  // Admin Controls
  const [adminSelectedStatus, setAdminSelectedStatus] = useState<IssueStatus>("Reported");
  const [adminStatusNotes, setAdminStatusNotes] = useState("");
  const [updatingStatusId, setUpdatingStatusId] = useState<string | null>(null);
  
  // Custom advanced admin management states
  const [adminSubTab, setAdminSubTab] = useState<"pipeline" | "citizens" | "insights" | "database">("pipeline");
  const [adminUsers, setAdminUsers] = useState<UserProfile[]>([]);
  const [adminUserSearch, setAdminUserSearch] = useState("");
  const [adminReportSearch, setAdminReportSearch] = useState("");
  const [adminReportCategoryFilter, setAdminReportCategoryFilter] = useState("all");
  const [adminReportStatusFilter, setAdminReportStatusFilter] = useState("all");
  const [adminReportSeverityFilter, setAdminReportSeverityFilter] = useState("all");
  const [selectedAdminUser, setSelectedAdminUser] = useState<UserProfile | null>(null);

  // Live Database Viewer States
  const [dbCollection, setDbCollection] = useState<"issues" | "users" | "notifications">("issues");
  const [dbSelectedDocumentId, setDbSelectedDocumentId] = useState<string | null>(null);
  const [dbCustomNotificationText, setDbCustomNotificationText] = useState("");
  const [dbCustomNotificationUserId, setDbCustomNotificationUserId] = useState("");
  const [dbSearchQuery, setDbSearchQuery] = useState("");
  const [dbIsSyncing, setDbIsSyncing] = useState(false);
  const [dbAllNotifications, setDbAllNotifications] = useState<Notification[]>([]);
  const [dbEditingDocId, setDbEditingDocId] = useState<string | null>(null);
  const [dbEditingRawJson, setDbEditingRawJson] = useState<string>("");
  const [dbEditMode, setDbEditMode] = useState<"raw" | "form" | "json-edit">("raw");
  const [dbEditingFields, setDbEditingFields] = useState<any>({});
  
  // Work order dispatch inputs
  const [crewName, setCrewName] = useState("Public Works Team Alpha");
  const [crewSize, setCrewSize] = useState<number>(4);
  const [crewLead, setCrewLead] = useState("Inspector Michael Vance");
  const [crewNotes, setCrewNotes] = useState("Emergency site containment, road safety barrier assembly, and cold-asphalt patching.");
  const [crewTargetDate, setCrewTargetDate] = useState("2026-06-30");

  // Notification Pane
  const [showNotifPane, setShowNotifPane] = useState(false);

  // Signin & Signup Form States
  const [authMode, setAuthMode] = useState<"signin" | "signup">("signin");
  const [authEmail, setAuthEmail] = useState("");
  const [authPassword, setAuthPassword] = useState("");
  const [authName, setAuthName] = useState("");
  const [authRole, setAuthRole] = useState<"citizen" | "admin">("citizen");
  const [authAvatarUrl, setAuthAvatarUrl] = useState("");
  const [authError, setAuthError] = useState("");
  const [authLoading, setAuthLoading] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Leaflet Map Refs
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstance = useRef<any>(null);
  const markersGroup = useRef<any>(null);
  const heatmapCircles = useRef<any[]>([]);
  const [heatmapMode, setHeatmapMode] = useState<boolean>(false);

  // Load Initial Session & Data
  useEffect(() => {
    fetchProfile();
    fetchIssues();
    fetchNotifications();
    fetchPredictiveInsights();
    fetchLeaderboard();
  }, []);

  // Sync admin data when active tab becomes admin or user logs in
  useEffect(() => {
    if (user?.role === "admin") {
      fetchAdminUsers();
      fetchDbAllNotifications();
    }
  }, [user, activeTab]);

  // Sync dark class on document element
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
  }, [darkMode]);

  // Leaflet Map Initialization & Sync
  useEffect(() => {
    if (!mapRef.current) return;
    const L = (window as any).L;
    if (!L) return;

    if (!mapInstance.current) {
      // Map configuration focused on San Francisco
      mapInstance.current = L.map(mapRef.current, {
        center: [37.7749, -122.4194],
        zoom: 12,
        zoomControl: false,
      });

      L.control.zoom({ position: "bottomright" }).addTo(mapInstance.current);

      // Voyager elegant styling
      L.tileLayer("https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png", {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> &copy; <a href="https://carto.com/attributions">CARTO</a>',
        subdomains: "abcd",
        maxZoom: 20,
      }).addTo(mapInstance.current);

      markersGroup.current = L.layerGroup().addTo(mapInstance.current);
    }

    // Update map views and pins on issue changes or filters
    updateMapMarkers();

    // Map Click to capture location for new reports
    mapInstance.current.off("click");
    mapInstance.current.on("click", (e: any) => {
      setFormLatitude(e.latlng.lat);
      setFormLongitude(e.latlng.lng);
      // If we are in reporting mode, notify user
      if (activeTab === "report") {
        const tempMarker = L.marker(e.latlng, {
          icon: L.divIcon({
            html: `<div class="w-6 h-6 bg-rose-500 rounded-full border-2 border-white flex items-center justify-center shadow-lg animate-bounce text-white text-[10px] font-bold">+</div>`,
            className: "",
            iconSize: [24, 24],
            iconAnchor: [12, 12]
          })
        });
        // Clear temp marker on previous triggers
        if ((window as any).tempReportMarker) {
          mapInstance.current.removeLayer((window as any).tempReportMarker);
        }
        tempMarker.addTo(mapInstance.current);
        (window as any).tempReportMarker = tempMarker;
      }
    });

  }, [issues, filterCategory, filterStatus, heatmapMode, activeTab]);

  const updateMapMarkers = () => {
    const L = (window as any).L;
    if (!L || !mapInstance.current) return;

    // Clear existing markers/circles
    markersGroup.current.clearLayers();
    heatmapCircles.current.forEach(c => mapInstance.current.removeLayer(c));
    heatmapCircles.current = [];

    // Filter issues matching dashboard settings
    const filtered = issues.filter(issue => {
      if (filterCategory !== "all" && issue.category !== filterCategory) return false;
      if (filterStatus !== "all" && issue.status !== filterStatus) return false;
      return true;
    });

    if (heatmapMode) {
      // Draw Glowing Heatmap layers
      filtered.forEach(issue => {
        const radius = issue.urgencyScore * 5; // scaled radius
        const color = getSeverityColor(issue.severity);
        const circle = L.circle([issue.latitude, issue.longitude], {
          color: color.border,
          fillColor: color.fill,
          fillOpacity: 0.5,
          radius: radius,
        }).addTo(mapInstance.current);

        circle.bindPopup(`
          <div class="p-2 font-sans">
            <span class="text-xs font-mono font-bold uppercase tracking-wider text-rose-500">Urgency: ${issue.urgencyScore}%</span>
            <h4 class="font-bold text-sm text-slate-800 dark:text-slate-100">${issue.title}</h4>
            <p class="text-xs text-slate-500 mt-1">Severity: ${issue.severity}</p>
          </div>
        `);
        heatmapCircles.current.push(circle);
      });
    } else {
      // Draw customized markers
      filtered.forEach(issue => {
        const color = getSeverityColor(issue.severity);
        const iconHtml = `
          <div class="relative flex items-center justify-center">
            <div class="absolute w-8 h-8 rounded-full ${color.bg} opacity-20 animate-ping"></div>
            <div class="w-8 h-8 rounded-full ${color.bg} border-2 border-white flex items-center justify-center shadow-lg text-white font-bold text-xs transition-transform hover:scale-110">
              ${getCategoryEmoji(issue.category)}
            </div>
          </div>
        `;

        const marker = L.marker([issue.latitude, issue.longitude], {
          icon: L.divIcon({
            html: iconHtml,
            className: "",
            iconSize: [32, 32],
            iconAnchor: [16, 16],
          })
        });

        marker.on("click", () => {
          setSelectedIssue(issue);
          // Auto route to details modal/panel
        });

        markersGroup.current.addLayer(marker);
      });
    }
  };

  const getSeverityColor = (sev: string) => {
    switch (sev) {
      case "Critical":
        return { bg: "bg-red-600", text: "text-red-600", fill: "#ef4444", border: "#dc2626" };
      case "High":
        return { bg: "bg-orange-500", text: "text-orange-500", fill: "#f97316", border: "#ea580c" };
      case "Medium":
        return { bg: "bg-amber-500", text: "text-amber-500", fill: "#f59e0b", border: "#d97706" };
      default:
        return { bg: "bg-zinc-500", text: "text-zinc-500", fill: "#71717a", border: "#52525b" };
    }
  };

  const getCategoryEmoji = (cat: IssueCategory) => {
    switch (cat) {
      case "potholes": return "🕳️";
      case "water_leakages": return "💧";
      case "garbage_accumulation": return "🗑️";
      case "broken_streetlights": return "💡";
      case "damaged_infrastructure": return "🚧";
      case "road_hazards": return "⚠️";
    }
  };

  const getCategoryLabel = (cat: IssueCategory) => {
    return cat.split("_").map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(" ");
  };

  // REST API Integrations
  const fetchProfile = async () => {
    try {
      const res = await fetch("/api/auth/me");
      const data = await res.json();
      setUser(data);
    } catch (err) {
      console.error(err);
    }
  };

  const fetchIssues = async () => {
    try {
      const res = await fetch("/api/issues");
      const data = await res.json();
      setIssues(data);
    } catch (err) {
      console.error(err);
    }
  };

  const fetchNotifications = async () => {
    try {
      const res = await fetch("/api/notifications");
      const data = await res.json();
      setNotifications(data);
    } catch (err) {
      console.error(err);
    }
  };

  const fetchPredictiveInsights = async () => {
    try {
      const res = await fetch("/api/predictive/insights");
      const data = await res.json();
      setPredictive(data);
    } catch (err) {
      console.error(err);
    }
  };

  const fetchLeaderboard = async () => {
    try {
      const res = await fetch("/api/leaderboard");
      const data = await res.json();
      setLeaderboard(data.list);
      setBadges(data.badges);
    } catch (err) {
      console.error(err);
    }
  };

  // Helper to trigger Gemini Vision Analysis on any image base64
  const analyzeIncidentPhoto = async (base64String: string, mimeType: string = "image/jpeg") => {
    setAnalyzingImage(true);
    try {
      const res = await fetch("/api/gemini/analyze-report", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          imageBase64: base64String,
          mimeType: mimeType
        })
      });
      const aiAnalysis = await res.json();
      if (aiAnalysis && !aiAnalysis.error) {
        setFormTitle(aiAnalysis.title || "");
        setFormCategory(aiAnalysis.category || "potholes");
        setFormDescription(aiAnalysis.description || "");
        setFormSeverity(aiAnalysis.severity || "Medium");
      }
    } catch (err) {
      console.error("AI Analysis failed:", err);
    } finally {
      setAnalyzingImage(false);
    }
  };

  // Image Upload with drag/drop, trigger Gemini Vision Analysis
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onloadend = async () => {
      const base64String = reader.result as string;
      setFormImage(base64String);
      await analyzeIncidentPhoto(base64String, file.type);
    };
    reader.readAsDataURL(file);
  };

  // Start Live Camera stream
  const startCamera = async (deviceId?: string) => {
    setCameraError("");
    try {
      if (videoStreamRef.current) {
        videoStreamRef.current.getTracks().forEach((track) => track.stop());
      }
      
      const constraints: MediaStreamConstraints = {
        video: deviceId 
          ? { deviceId: { exact: deviceId } } 
          : { facingMode: { ideal: "environment" } }
      };

      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      videoStreamRef.current = stream;
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
      setIsCameraActive(true);

      // Enumerate camera devices
      const devices = await navigator.mediaDevices.enumerateDevices();
      const videoDevices = devices.filter((d) => d.kind === "videoinput");
      setCameraDevices(videoDevices);
      
      if (videoDevices.length > 0 && !deviceId) {
        // Find matching device or default to first
        const matched = videoDevices.find(
          (d) => d.label.toLowerCase().includes("back") || d.label.toLowerCase().includes("environment")
        ) || videoDevices[0];
        setSelectedDeviceId(matched.deviceId);
      }
    } catch (err: any) {
      console.error("Camera access failed:", err);
      setCameraError(
        err?.message || "Could not access camera. Please check frame permissions and camera settings."
      );
    }
  };

  // Stop Live Camera stream
  const stopCamera = () => {
    if (videoStreamRef.current) {
      videoStreamRef.current.getTracks().forEach((track) => track.stop());
      videoStreamRef.current = null;
    }
    setIsCameraActive(false);
  };

  // Capture a snapshot from the live video stream
  const capturePhoto = () => {
    if (!videoRef.current) return;
    const video = videoRef.current;
    
    try {
      const canvas = document.createElement("canvas");
      // Use video's intrinsic resolution or fallback to stream/standard values
      canvas.width = video.videoWidth || 640;
      canvas.height = video.videoHeight || 480;
      
      const ctx = canvas.getContext("2d");
      if (ctx) {
        // Horizontal flip correction if using self-facing camera
        const activeDevice = cameraDevices.find((d) => d.deviceId === selectedDeviceId);
        const isFrontCamera = activeDevice && (
          activeDevice.label.toLowerCase().includes("front") || 
          activeDevice.label.toLowerCase().includes("user")
        );
        
        if (isFrontCamera) {
          ctx.translate(canvas.width, 0);
          ctx.scale(-1, 1);
        }

        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const base64String = canvas.toDataURL("image/jpeg");
        setFormImage(base64String);
        stopCamera();
        
        // Analyze image
        analyzeIncidentPhoto(base64String, "image/jpeg");
      }
    } catch (err) {
      console.error("Failed to capture snapshot:", err);
    }
  };

  const submitIssueReport = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmittingReport(true);
    try {
      const res = await fetch("/api/issues", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: formTitle,
          category: formCategory,
          description: formDescription,
          imageUrl: formImage,
          latitude: formLatitude,
          longitude: formLongitude,
          severity: formSeverity
        })
      });

      if (res.ok) {
        // Clear Form & Refresh State
        setFormTitle("");
        setFormDescription("");
        setFormImage("");
        // Notify user & Route back to home/explore
        await fetchIssues();
        await fetchProfile();
        await fetchNotifications();
        setActiveTab("explore");
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsSubmittingReport(false);
    }
  };

  // Upvoting / Community Verification
  const verifyIssue = async (issueId: string, isUpvote: boolean) => {
    setIsCastingVote(true);
    try {
      const res = await fetch(`/api/issues/${issueId}/verify`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ isUpvote })
      });
      if (res.ok) {
        const updated = await res.json();
        // Update issues list in place to maintain selected status
        setIssues(prev => prev.map(i => i.id === issueId ? { ...i, ...updated } : i));
        setSelectedIssue(updated);
        await fetchProfile();
        await fetchLeaderboard();
      } else {
        const err = await res.json();
        alert(err.error || "Failed to verify issue");
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsCastingVote(false);
    }
  };

  // Community Comments
  const submitComment = async (issueId: string) => {
    if (!commentText.trim()) return;
    try {
      const res = await fetch(`/api/issues/${issueId}/comments`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: commentText })
      });
      if (res.ok) {
        const comment = await res.json();
        setIssues(prev => prev.map(i => {
          if (i.id === issueId) {
            return { ...i, comments: [...i.comments, comment] };
          }
          return i;
        }));
        // Update selected issue reference
        if (selectedIssue && selectedIssue.id === issueId) {
          setSelectedIssue(prev => prev ? { ...prev, comments: [...prev.comments, comment] } : null);
        }
        setCommentText("");
        await fetchProfile();
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Pulse AI Civic Assistant chatbot triggers
  const handleChatSend = async (customMessage?: string) => {
    const textToSend = customMessage || chatInput;
    if (!textToSend.trim()) return;

    // Append citizen message
    const userMsg: ChatMessage = {
      id: `u-${Date.now()}`,
      sender: "user",
      text: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    };

    setChatMessages(prev => [...prev, userMsg]);
    if (!customMessage) setChatInput("");
    setChatLoading(true);

    try {
      const res = await fetch("/api/gemini/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: textToSend,
          chatHistory: chatMessages.map(m => ({ role: m.sender === "user" ? "user" : "model", parts: [m.text] }))
        })
      });
      const data = await res.json();
      
      const aiMsg: ChatMessage = {
        id: `ai-${Date.now()}`,
        sender: "ai",
        text: data.text,
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
      };
      setChatMessages(prev => [...prev, aiMsg]);
    } catch (err) {
      console.error(err);
    } finally {
      setChatLoading(false);
    }
  };

  // AI Report Document Complaint Generator
  const generateOfficialReportDoc = async (issueId: string) => {
    setGeneratingReportId(issueId);
    try {
      const res = await fetch("/api/reports/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ issueId })
      });
      if (res.ok) {
        const data = await res.json();
        setGeneratedReport(data);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setGeneratingReportId(null);
    }
  };

  // Admin update issue lifecycle status
  const updateIssueStatusAdmin = async (issueId: string) => {
    setUpdatingStatusId(issueId);
    try {
      const res = await fetch(`/api/issues/${issueId}/status`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          status: adminSelectedStatus,
          notes: adminStatusNotes
        })
      });
      if (res.ok) {
        const updated = await res.json();
        setIssues(prev => prev.map(i => i.id === issueId ? { ...i, ...updated } : i));
        setSelectedIssue(updated);
        setAdminStatusNotes("");
        await fetchIssues();
      }
    } catch (err) {
      console.error(err);
    } finally {
      setUpdatingStatusId(null);
    }
  };

  // Fetch users roster for administrator management
  const fetchAdminUsers = async () => {
    try {
      const res = await fetch("/api/admin/users");
      if (res.ok) {
        const data = await res.json();
        setAdminUsers(data);
      }
    } catch (err) {
      console.error("Failed to fetch registered users roster", err);
    }
  };

  const fetchDbAllNotifications = async () => {
    try {
      const res = await fetch("/api/admin/database/notifications");
      if (res.ok) {
        const data = await res.json();
        setDbAllNotifications(data);
      }
    } catch (err) {
      console.error("Failed to fetch all notifications for explorer", err);
    }
  };

  const handleSeedDatabase = async () => {
    setDbIsSyncing(true);
    try {
      const res = await fetch("/api/admin/database/seed", { method: "POST" });
      if (res.ok) {
        alert("Database successfully reset and synced to Firestore initial defaults!");
        await fetchIssues();
        await fetchAdminUsers();
        await fetchNotifications();
        await fetchDbAllNotifications();
        setDbSelectedDocumentId(null);
      } else {
        const errData = await res.json();
        alert("Failed to seed database: " + (errData.error || "Unknown error"));
      }
    } catch (err: any) {
      alert("Error seeding database: " + err.message);
    } finally {
      setDbIsSyncing(false);
    }
  };

  const adjustUserPoints = async (userId: string, points: number, score: number) => {
    try {
      const res = await fetch(`/api/admin/users/${userId}/points`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ points, reputationScore: score })
      });
      if (res.ok) {
        const updatedUser = await res.json();
        setSelectedAdminUser(updatedUser);
        await fetchAdminUsers();
        await fetchLeaderboard();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const toggleUserBadge = async (userId: string, badgeId: string, action: "award" | "revoke") => {
    try {
      const res = await fetch(`/api/admin/users/${userId}/badges`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ badgeId, action })
      });
      if (res.ok) {
        const updatedUser = await res.json();
        setSelectedAdminUser(updatedUser);
        await fetchAdminUsers();
        await fetchLeaderboard();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const moderateIssueParameters = async (issueId: string, severity: string, urgency: number, duplicateOf?: string) => {
    try {
      const res = await fetch(`/api/admin/issues/${issueId}/moderate`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ severity, urgencyScore: urgency, duplicateOf })
      });
      if (res.ok) {
        const updated = await res.json();
        setIssues(prev => prev.map(i => i.id === issueId ? { ...i, ...updated } : i));
        setSelectedIssue(updated);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const deleteIssueAdmin = async (issueId: string) => {
    if (!window.confirm("Are you sure you want to permanently delete this citizen report from the city database? This action is irreversible.")) return;
    try {
      const res = await fetch(`/api/admin/issues/${issueId}`, { method: "DELETE" });
      if (res.ok) {
        setIssues(prev => prev.filter(i => i.id !== issueId));
        setSelectedIssue(null);
        await fetchIssues();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const deleteCommentAdmin = async (issueId: string, commentId: string) => {
    if (!window.confirm("Are you sure you want to remove this comment?")) return;
    try {
      const res = await fetch(`/api/admin/issues/${issueId}/comments/${commentId}`, { method: "DELETE" });
      if (res.ok) {
        const updatedIssue = await res.json();
        setIssues(prev => prev.map(i => i.id === issueId ? updatedIssue : i));
        setSelectedIssue(updatedIssue);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const deleteDbNotification = async (id: string) => {
    if (!window.confirm("Are you sure you want to delete this notification document?")) return;
    try {
      const res = await fetch(`/api/admin/database/notifications/${id}`, { method: "DELETE" });
      if (res.ok) {
        alert("Notification deleted successfully.");
        await fetchDbAllNotifications();
        if (dbSelectedDocumentId === id) setDbSelectedDocumentId(null);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const deleteDbUser = async (id: string) => {
    if (!window.confirm("Are you sure you want to permanently delete this user document? This will remove their record from Firestore.")) return;
    try {
      const res = await fetch(`/api/admin/database/users/${id}`, { method: "DELETE" });
      if (res.ok) {
        alert("User document deleted successfully.");
        await fetchAdminUsers();
        if (dbSelectedDocumentId === id) setDbSelectedDocumentId(null);
      } else {
        const data = await res.json();
        alert(`Failed to delete user: ${data.error || "Unknown error"}`);
      }
    } catch (err) {
      console.error(err);
      alert("Error deleting user document");
    }
  };

  const updateDbDocument = async (collectionName: string, id: string, updatedFields: any) => {
    try {
      const res = await fetch(`/api/admin/database/${collectionName}/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updatedFields)
      });
      if (res.ok) {
        alert("Document updated successfully in database.");
        if (collectionName === "users") {
          await fetchAdminUsers();
        } else if (collectionName === "issues") {
          await fetchIssues();
        } else if (collectionName === "notifications") {
          await fetchDbAllNotifications();
        }
        return true;
      } else {
        const err = await res.json();
        alert(`Failed to update document: ${err.error || "Unknown error"}`);
        return false;
      }
    } catch (err) {
      console.error(err);
      alert("Error updating document");
      return false;
    }
  };

  const handleSelectDbDocument = (docItem: any) => {
    const isSelected = dbSelectedDocumentId === docItem.id;
    const nextId = isSelected ? null : docItem.id;
    setDbSelectedDocumentId(nextId);
    if (nextId) {
      setDbEditingDocId(nextId);
      setDbEditingFields({ ...docItem });
      setDbEditingRawJson(JSON.stringify(docItem, null, 2));
    } else {
      setDbEditingDocId(null);
    }
  };

  const handleCreateDbNotification = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!dbCustomNotificationUserId || !dbCustomNotificationText) {
      alert("Please fill in both User ID and Message text.");
      return;
    }
    try {
      const res = await fetch("/api/admin/database/notifications", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: dbCustomNotificationUserId,
          title: "System Broadcast Alert",
          message: dbCustomNotificationText,
          type: "alert"
        })
      });
      if (res.ok) {
        alert("Notification successfully dispatched and written to Firestore!");
        setDbCustomNotificationText("");
        setDbCustomNotificationUserId("");
        await fetchDbAllNotifications();
      } else {
        alert("Failed to create notification.");
      }
    } catch (err) {
      console.error(err);
    }
  };

  const dispatchWorkOrder = async (issueId: string) => {
    setUpdatingStatusId(issueId);
    try {
      const notes = `DISPATCH WORK ORDER: Assigned to [${crewName}] (Size: ${crewSize}, Lead: ${crewLead}). Target Completion: ${crewTargetDate}. Instructions: ${crewNotes}`;
      const res = await fetch(`/api/issues/${issueId}/status`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          status: "Assigned",
          notes
        })
      });
      if (res.ok) {
        const updated = await res.json();
        setIssues(prev => prev.map(i => i.id === issueId ? { ...i, ...updated } : i));
        setSelectedIssue(updated);
        setCrewNotes("Emergency site containment, road safety barrier assembly, and cold-asphalt patching.");
      }
    } catch (err) {
      console.error(err);
    } finally {
      setUpdatingStatusId(null);
    }
  };

  const markNotificationRead = async (id: string) => {
    try {
      await fetch(`/api/notifications/${id}/read`, { method: "PUT" });
      fetchNotifications();
    } catch (err) {
      console.error(err);
    }
  };

  const simulateLoginChange = async (email: string) => {
    try {
      const password = email === "gauravsawant702@gmail.com" ? "admin2003" : "password123";
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password })
      });
      const data = await res.json();
      setUser(data);
      if (data.role === "admin") {
        setActiveTab("admin");
      } else {
        setActiveTab("dashboard");
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleSignOut = async () => {
    try {
      await fetch("/api/auth/logout", { method: "POST" });
      setUser(null);
      setActiveTab("dashboard");
    } catch (err) {
      console.error(err);
    }
  };

  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError("");
    setAuthLoading(true);
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: authEmail, password: authPassword })
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "Failed to sign in.");
      }
      setUser(data);
      if (data.role === "admin") {
        setActiveTab("admin");
      } else {
        setActiveTab("dashboard");
      }
    } catch (err: any) {
      setAuthError(err.message || "An error occurred during sign in.");
    } finally {
      setAuthLoading(false);
    }
  };

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError("");
    setAuthLoading(true);
    try {
      const res = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: authEmail,
          password: authPassword,
          name: authName,
          role: authRole,
          avatarUrl: authAvatarUrl
        })
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "Failed to sign up.");
      }
      setUser(data);
      if (data.role === "admin") {
        setActiveTab("admin");
      } else {
        setActiveTab("dashboard");
      }
    } catch (err: any) {
      setAuthError(err.message || "An error occurred during sign up.");
    } finally {
      setAuthLoading(false);
    }
  };

  const handleQuickLogin = async (email: string, pass: string) => {
    setAuthError("");
    setAuthLoading(true);
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password: pass })
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "Failed to sign in.");
      }
      setUser(data);
      if (data.role === "admin") {
        setActiveTab("admin");
      } else {
        setActiveTab("dashboard");
      }
    } catch (err: any) {
      setAuthError(err.message || "An error occurred.");
    } finally {
      setAuthLoading(false);
    }
  };

  // Mocking PDF print/download functionality beautifully
  const handlePrintReport = () => {
    window.print();
  };

  // Stats Counters
  const totalReports = issues.length;
  const resolvedReports = issues.filter(i => i.status === "Resolved").length;
  const activeReports = totalReports - resolvedReports;
  const criticalCount = issues.filter(i => i.severity === "Critical" && i.status !== "Resolved").length;

  if (!user) {
    return (
      <div className={`min-h-screen flex items-center justify-center bg-slate-50 text-slate-900 dark:bg-slate-950 dark:text-slate-100 p-4 transition-colors duration-200 ${darkMode ? "dark" : ""}`}>
        {/* Decorative background gradients */}
        <div className="absolute top-0 left-0 w-96 h-96 bg-violet-400/10 dark:bg-violet-600/5 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-indigo-400/10 dark:bg-indigo-600/5 rounded-full blur-3xl pointer-events-none" />

        <div className="w-full max-w-md bg-white dark:bg-zinc-900 rounded-3xl border border-slate-100 dark:border-zinc-800/80 p-8 relative overflow-hidden transition-all shadow-xl dark:shadow-2xl dark:shadow-violet-950/10">
          <div className="absolute top-4 right-4">
            <button
              onClick={() => setDarkMode(!darkMode)}
              className="p-2.5 rounded-xl bg-slate-100 dark:bg-zinc-800 hover:bg-violet-500 hover:text-white text-zinc-800 dark:text-zinc-200 transition-all border border-slate-200 dark:border-zinc-700 shadow-sm"
            >
              {darkMode ? <Sun size={18} /> : <Moon size={18} />}
            </button>
          </div>

          <div className="flex flex-col items-center mb-6">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-violet-600 to-indigo-600 flex items-center justify-center text-white font-display font-black text-3xl shadow-lg shadow-violet-500/20 mb-3">
              S
            </div>
            <h1 className="font-display font-black text-3xl tracking-tight text-slate-900 dark:text-white uppercase">
              <span className="bg-clip-text text-transparent bg-gradient-to-r from-violet-600 to-indigo-600">Street</span>Pulse
            </h1>
            <p className="text-xs text-zinc-500 dark:text-zinc-400 font-semibold mt-1">Smart AI Civic Issue Platform</p>
          </div>

          <div className="flex bg-slate-100 dark:bg-zinc-800 p-1.5 rounded-2xl mb-6 border border-slate-200/60 dark:border-zinc-700/60">
            <button
              onClick={() => { setAuthMode("signin"); setAuthError(""); }}
              className={`flex-1 py-2.5 text-xs font-bold rounded-xl transition-all ${
                authMode === "signin"
                  ? "bg-white dark:bg-zinc-900 text-violet-600 dark:text-violet-400 shadow-sm"
                  : "text-zinc-600 dark:text-zinc-400 hover:text-black dark:hover:text-zinc-200"
              }`}
            >
              Sign In
            </button>
            <button
              onClick={() => { setAuthMode("signup"); setAuthError(""); }}
              className={`flex-1 py-2.5 text-xs font-bold rounded-xl transition-all ${
                authMode === "signup"
                  ? "bg-white dark:bg-zinc-900 text-violet-600 dark:text-violet-400 shadow-sm"
                  : "text-zinc-600 dark:text-zinc-400 hover:text-black dark:hover:text-zinc-200"
              }`}
            >
              Sign Up / Register
            </button>
          </div>

          {authError && (
            <div className="mb-4 p-3 bg-red-50 dark:bg-red-950/30 text-red-600 dark:text-red-400 border border-red-100 dark:border-red-900 rounded-xl text-xs flex items-center gap-2">
              <AlertCircle size={14} className="shrink-0" />
              <span>{authError}</span>
            </div>
          )}

          {authMode === "signin" ? (
            <form onSubmit={handleSignIn} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-zinc-300 uppercase tracking-wider mb-1">
                  Email Address
                </label>
                <input
                  type="email"
                  required
                  value={authEmail}
                  onChange={(e) => setAuthEmail(e.target.value)}
                  placeholder="name@example.com"
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 dark:border-zinc-800 bg-white dark:bg-zinc-950 text-sm focus:outline-none focus:ring-2 focus:ring-violet-500 focus:border-violet-500 font-medium transition-all text-black dark:text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-zinc-300 uppercase tracking-wider mb-1">
                  Password
                </label>
                <input
                  type="password"
                  required
                  value={authPassword}
                  onChange={(e) => setAuthPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 dark:border-zinc-800 bg-white dark:bg-zinc-950 text-sm focus:outline-none focus:ring-2 focus:ring-violet-500 focus:border-violet-500 font-medium transition-all text-black dark:text-white"
                />
              </div>

              <button
                type="submit"
                disabled={authLoading}
                className="w-full py-3 canva-button-primary disabled:bg-zinc-300 text-white font-bold text-sm transition-all flex items-center justify-center gap-2 mt-2"
              >
                {authLoading ? (
                  <>
                    <Loader2 size={16} className="animate-spin" />
                    <span>Signing in...</span>
                  </>
                ) : (
                  <>
                    <span>Sign In</span>
                    <ArrowRight size={16} />
                  </>
                )}
              </button>
            </form>
          ) : (
            <form onSubmit={handleSignUp} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-zinc-300 uppercase tracking-wider mb-1">
                  Full Name
                </label>
                <input
                  type="text"
                  required
                  value={authName}
                  onChange={(e) => setAuthName(e.target.value)}
                  placeholder="e.g. John Doe"
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 dark:border-zinc-800 bg-white dark:bg-zinc-950 text-sm focus:outline-none focus:ring-2 focus:ring-violet-500 focus:border-violet-500 font-medium transition-all text-black dark:text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-zinc-300 uppercase tracking-wider mb-1">
                  Email Address
                </label>
                <input
                  type="email"
                  required
                  value={authEmail}
                  onChange={(e) => setAuthEmail(e.target.value)}
                  placeholder="e.g. john@example.com"
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 dark:border-zinc-800 bg-white dark:bg-zinc-950 text-sm focus:outline-none focus:ring-2 focus:ring-violet-500 focus:border-violet-500 font-medium transition-all text-black dark:text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-zinc-300 uppercase tracking-wider mb-1">
                  Password
                </label>
                <input
                  type="password"
                  required
                  value={authPassword}
                  onChange={(e) => setAuthPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 dark:border-zinc-800 bg-white dark:bg-zinc-950 text-sm focus:outline-none focus:ring-2 focus:ring-violet-500 focus:border-violet-500 font-medium transition-all text-black dark:text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-zinc-300 uppercase tracking-wider mb-1">
                  Profile Avatar
                </label>
                
                {/* DEVICE FILE UPLOAD FOR PROFILE PICTURES */}
                <div className="p-4 bg-slate-50 dark:bg-zinc-800/40 rounded-xl border border-dashed border-slate-200 dark:border-zinc-800">
                  <span className="block text-[11px] font-semibold text-zinc-500 dark:text-zinc-400 mb-2">
                    Upload an avatar image from your device:
                  </span>
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 rounded-full overflow-hidden bg-zinc-200 dark:bg-zinc-700 border border-zinc-300 dark:border-zinc-600 flex-shrink-0 flex items-center justify-center">
                      {authAvatarUrl ? (
                        <img src={authAvatarUrl} alt="Selected profile" className="w-full h-full object-cover" />
                      ) : (
                        <User size={20} className="text-zinc-400 dark:text-zinc-500" />
                      )}
                    </div>
                    <div className="flex-1">
                      <input
                        type="file"
                        id="profile-upload"
                        accept="image/*"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (file) {
                            const reader = new FileReader();
                            reader.onloadend = () => {
                              if (typeof reader.result === "string") {
                                setAuthAvatarUrl(reader.result);
                              }
                            };
                            reader.readAsDataURL(file);
                          }
                        }}
                        className="block w-full text-xs text-zinc-500 dark:text-zinc-400
                          file:mr-3 file:py-1.5 file:px-3
                          file:rounded-lg file:border-0
                          file:text-[11px] file:font-bold
                          file:bg-violet-100 file:text-violet-600
                          dark:file:bg-violet-950/40 dark:file:text-violet-400
                          hover:file:bg-violet-200 transition-all cursor-pointer"
                      />
                    </div>
                  </div>
                  {authAvatarUrl.startsWith("data:") && (
                    <div className="flex items-center gap-1.5 mt-2 text-[10px] text-emerald-600 dark:text-emerald-400 font-medium">
                      <span>✓ Custom image loaded successfully from device</span>
                    </div>
                  )}
                </div>
              </div>

              <button
                type="submit"
                disabled={authLoading}
                className="w-full py-3 canva-button-primary disabled:bg-zinc-300 text-white font-bold text-sm transition-all flex items-center justify-center gap-2"
              >
                {authLoading ? (
                  <>
                    <Loader2 size={16} className="animate-spin" />
                    <span>Creating profile...</span>
                  </>
                ) : (
                  <>
                    <span>Create Profile</span>
                    <Check size={16} />
                  </>
                )}
              </button>
            </form>
          )}
        </div>
      </div>
    );
  }

  const renderSidebarContents = (onItemClick?: () => void) => (
    <div className="h-full flex flex-col canva-sidebar text-slate-100">
      <div className="p-5 border-b border-white/5 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-violet-600 to-indigo-600 flex items-center justify-center text-white font-display font-black text-xl shadow-lg shadow-violet-500/20 border border-white/10">
            S
          </div>
          <div>
            <h1 className="font-display font-black text-lg tracking-tight text-white uppercase">
              <span className="text-violet-400">Street</span>Pulse
            </h1>
            <span className="text-[10px] font-mono tracking-wider uppercase text-violet-300 font-bold block">
              AI Civic Hub
            </span>
          </div>
        </div>
        <div className="flex items-center space-x-2 shrink-0">
          <button
            onClick={() => setDarkMode(!darkMode)}
            className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-violet-300 transition-all border border-white/10"
            title="Toggle Light/Dark Theme"
          >
            {darkMode ? <Sun size={18} /> : <Moon size={18} />}
          </button>
          {onItemClick && (
            <button
              onClick={onItemClick}
              className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-violet-300 transition-all border border-white/10"
              title="Close Navigation"
            >
              <X size={18} />
            </button>
          )}
        </div>
      </div>

      {/* LOGGED IN USER PROFILE SUMMARY */}
      {user && (
        <div className="p-4 border-b border-white/5 bg-white/5">
          <div className="flex items-center space-x-3">
            <img
              src={user.avatarUrl || BLANK_AVATAR}
              alt={user.name}
              className="w-10 h-10 rounded-full object-cover border-2 border-violet-500 shadow-sm"
            />
            <div className="flex-1 min-w-0">
              <p className="text-xs font-black truncate text-white">
                {user.name}
              </p>
              <div className="flex items-center space-x-1.5 mt-0.5">
                <Zap size={12} className="text-violet-400 fill-violet-400 animate-pulse" />
                <span className="text-[11px] font-bold text-slate-300">
                  {user.points} pts
                </span>
                <span className="text-[10px] bg-violet-600 text-white px-1.5 py-0.5 rounded font-black uppercase">
                  Rep: {user.reputationScore}%
                </span>
              </div>
            </div>
          </div>
          
          {/* Quick Badges preview */}
          <div className="flex gap-1 mt-2.5 overflow-x-auto py-1">
            {user.badges.map(bId => {
              const badge = badges.find(b => b.id === bId);
              return (
                <span
                  key={bId}
                  className="text-[9px] font-extrabold px-2 py-0.5 rounded-full whitespace-nowrap bg-violet-950/50 text-violet-300 border border-violet-500/20"
                  title={badge?.description}
                >
                  🏆 {badge?.name || bId}
                </span>
              );
            })}
          </div>
        </div>
      )}

      {/* TABS NAVIGATION */}
      <nav className="flex-1 p-3 space-y-1.5 overflow-y-auto">
        {(user?.role === "admin"
          ? [
              { id: "admin", label: "Admin Command Centre", icon: Settings },
              { id: "explore", label: "Explore Issues Map", icon: MapPin },
              { id: "chatbot", label: "Pulse AI Assistant", icon: MessageSquare },
            ]
          : [
              { id: "dashboard", label: "Dashboard", icon: BarChart3 },
              { id: "explore", label: "Explore Issues", icon: MapPin },
              { id: "report", label: "Report Local Issue", icon: PlusCircle, highlight: true },
              { id: "chatbot", label: "Pulse AI Assistant", icon: MessageSquare },
              { id: "leaderboard", label: "Leaderboard & Badges", icon: Award },
            ]
        ).map(tab => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;

          return (
            <button
              key={tab.id}
              onClick={() => {
                setActiveTab(tab.id as any);
                setSelectedIssue(null);
                if (onItemClick) onItemClick();
              }}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-sm transition-all duration-200 group ${
                isActive
                  ? "bg-gradient-to-r from-violet-600 to-indigo-600 text-white font-bold shadow-lg shadow-violet-600/20"
                  : "text-slate-300 hover:bg-white/5 hover:text-white"
              }`}
            >
              <div className="flex items-center space-x-3">
                <Icon size={18} className={isActive ? "scale-110 transition-transform text-white" : "opacity-85 text-violet-400 group-hover:text-violet-300 transition-colors"} />
                <span className={isActive ? "font-bold" : "font-medium"}>{tab.label}</span>
              </div>
              {tab.highlight && !isActive && (
                <span className="w-2.5 h-2.5 rounded-full bg-fuchsia-500 shadow-[0_0_8px_rgba(236,72,153,0.8)] animate-pulse"></span>
              )}
            </button>
          );
        })}
      </nav>

      <div className="p-4 border-t border-white/5 bg-white/2 space-y-3">
        <button
          onClick={handleSignOut}
          className="w-full py-2.5 bg-red-500/10 hover:bg-red-600 text-red-400 hover:text-white text-xs font-bold rounded-xl border border-red-500/20 hover:border-red-600 transition-all flex items-center justify-center gap-1.5"
        >
          <span>Sign Out Profile</span>
        </button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 dark:bg-slate-950 dark:text-slate-100 flex flex-col md:flex-row font-sans transition-colors duration-200">
      
      {/* DESKTOP SIDEBAR NAVIGATION PANEL */}
      <aside className="hidden md:flex md:w-64 flex-col shrink-0 z-30 shadow-xl">
        {renderSidebarContents()}
      </aside>

      {/* MOBILE DRAWER (Slide-out navigation menu for Android & mobile screens) */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 md:hidden flex">
          {/* Backdrop overlay */}
          <div 
            className="fixed inset-0 bg-black/60 backdrop-blur-sm transition-opacity"
            onClick={() => setMobileMenuOpen(false)}
          />
          {/* Sidebar Drawer container */}
          <div className="relative flex flex-col w-72 max-w-xs h-full bg-slate-900 text-white shadow-2xl animate-in slide-in-from-left duration-200 border-r border-white/5">
            <div className="flex-1 overflow-y-auto">
              {renderSidebarContents(() => setMobileMenuOpen(false))}
            </div>
          </div>
        </div>
      )}

      {/* MAIN SCREEN AREA */}
      <main className="flex-1 flex flex-col min-w-0 overflow-hidden bg-slate-50 dark:bg-slate-950">
        
        {/* HEADER */}
        <header className="h-16 bg-white/80 dark:bg-zinc-900/80 backdrop-blur-md border-b border-slate-100 dark:border-zinc-800/80 flex items-center justify-between px-4 md:px-6 z-30 shrink-0">
          <div className="flex items-center space-x-3 md:space-x-4">
            {/* Mobile Hamburger menu */}
            <button
              onClick={() => setMobileMenuOpen(true)}
              className="md:hidden p-2 rounded-lg bg-slate-100 dark:bg-zinc-850 hover:bg-slate-200 dark:hover:bg-zinc-800 text-zinc-600 dark:text-zinc-300 transition-all border border-slate-200 dark:border-zinc-800"
              title="Open Navigation"
            >
              <Menu size={20} />
            </button>
            <h2 className="font-display font-bold text-sm sm:text-lg md:text-xl text-zinc-800 dark:text-zinc-100 uppercase tracking-tight truncate">
              {activeTab === "dashboard" && "Dashboard Insights"}
              {activeTab === "explore" && "Local Issues Map & Feed"}
              {activeTab === "report" && "Report an Issue"}
              {activeTab === "chatbot" && "Pulse AI Assistant"}
              {activeTab === "leaderboard" && "Impact Leaderboard"}
              {activeTab === "admin" && "Administrator Command Centre"}
            </h2>
          </div>

          <div className="flex items-center space-x-3">
            {/* Notifications Button */}
            <div className="relative">
              <button
                onClick={() => setShowNotifPane(!showNotifPane)}
                className="p-2 text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg relative transition-all"
              >
                <Bell size={20} />
                {notifications.filter(n => !n.read).length > 0 && (
                  <span className="absolute top-1.5 right-1.5 w-2.5 h-2.5 bg-red-500 rounded-full border-2 border-white dark:border-slate-900 animate-pulse"></span>
                )}
              </button>

              {/* Notification Pane Dropdown */}
              {showNotifPane && (
                <div className="absolute right-0 mt-2 w-80 bg-white dark:bg-slate-900 rounded-xl shadow-xl border border-slate-200 dark:border-slate-800 z-50 p-4 max-h-96 overflow-y-auto">
                  <div className="flex items-center justify-between mb-3 pb-2 border-b border-slate-100 dark:border-slate-800">
                    <span className="font-bold text-xs text-slate-500 tracking-wider uppercase">Notifications</span>
                    <button
                      onClick={() => setShowNotifPane(false)}
                      className="text-xs font-bold text-yellow-500 hover:underline"
                    >
                      Close
                    </button>
                  </div>
                  <div className="space-y-2.5">
                    {notifications.length === 0 ? (
                      <p className="text-xs text-slate-400 text-center py-4">No active notifications</p>
                    ) : (
                      notifications.map(notif => (
                        <div
                          key={notif.id}
                          className={`p-2.5 rounded-lg border text-xs transition-colors cursor-pointer ${
                            notif.read
                              ? "bg-slate-50/50 dark:bg-slate-900/50 border-slate-100 dark:border-slate-800 text-slate-500"
                              : "bg-yellow-400/10 dark:bg-yellow-950/20 border-yellow-200/50 dark:border-yellow-900/50 text-zinc-800 dark:text-zinc-200 font-bold"
                          }`}
                          onClick={() => {
                            markNotificationRead(notif.id);
                            if (notif.issueId) {
                              const issue = issues.find(i => i.id === notif.issueId);
                              if (issue) setSelectedIssue(issue);
                            }
                            setShowNotifPane(false);
                          }}
                        >
                          <div className="flex items-center justify-between mb-1">
                            <span className="font-bold uppercase tracking-wide text-[10px] text-yellow-500 dark:text-yellow-400">
                              {notif.type.replace("_", " ")}
                            </span>
                            <span className="text-[9px] text-slate-400">
                              {new Date(notif.createdAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                            </span>
                          </div>
                          <p className="font-semibold mb-0.5">{notif.title}</p>
                          <p className="text-slate-500 dark:text-slate-400 text-[11px] leading-relaxed">{notif.text}</p>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Current Ward Display Widget */}
            <div className="hidden lg:flex items-center space-x-2 bg-slate-100 dark:bg-slate-800 px-3.5 py-1.5 rounded-lg text-xs font-semibold text-slate-600 dark:text-slate-300">
              <MapPin size={14} className="text-emerald-500" />
              <span>Ward 4 (Oakland-SF)</span>
            </div>
          </div>
        </header>

        {/* CONTENT SWITCHER */}
        <div className="flex-1 overflow-y-auto flex flex-col md:flex-row relative">
          
          {/* MAP CANVAS DIV (ONLY DISPLAY ON DASHBOARD & EXPLORE) */}
          <div
            className={`transition-all duration-300 relative shrink-0 ${
              activeTab === "dashboard" || activeTab === "explore"
                ? "w-full md:w-[45%] h-[280px] md:h-auto border-b md:border-b-0 md:border-r border-slate-200 dark:border-slate-800"
                : "w-0 h-0 overflow-hidden border-none"
            }`}
          >
            <div ref={mapRef} className="w-full h-full absolute inset-0 bg-slate-200 dark:bg-slate-900"></div>

            {/* Map Action Floating Panel */}
            {(activeTab === "dashboard" || activeTab === "explore") && (
              <div className="absolute top-4 left-4 z-20 flex flex-col space-y-2">
                <button
                  onClick={() => setHeatmapMode(!heatmapMode)}
                  className={`px-3 py-2 rounded-lg text-xs font-bold shadow-lg flex items-center space-x-1.5 transition-all ${
                    heatmapMode
                      ? "bg-rose-500 text-white ring-2 ring-rose-300"
                      : "bg-white text-slate-800 hover:bg-slate-50 dark:bg-slate-800 dark:text-white"
                  }`}
                >
                  <Activity size={14} />
                  <span>{heatmapMode ? "Heatmap Active" : "Heatmap Mode"}</span>
                </button>
              </div>
            )}
          </div>

          {/* PAGE CONTENT CONTAINER */}
          <div className="flex-1 p-6 overflow-y-auto max-w-full">
            
            {/* 1. DASHBOARD PAGE */}
            {activeTab === "dashboard" && (
              <div className="space-y-6">
                {/* LIVE STATISTICS BANNER BENTO STYLE */}
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                  <div className="canva-card p-5">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-semibold text-slate-500 dark:text-zinc-400 uppercase tracking-wider">Total Reports</span>
                      <div className="p-2.5 bg-violet-50 dark:bg-violet-950/40 text-violet-600 dark:text-violet-400 rounded-xl border border-violet-100 dark:border-violet-900/30">
                        <FileText size={16} />
                      </div>
                    </div>
                    <p className="text-3xl font-bold font-display text-slate-900 dark:text-white mt-1">{totalReports}</p>
                    <span className="text-[10px] text-zinc-500 dark:text-zinc-400 font-bold block mt-1.5">Sourced from citizen units</span>
                  </div>

                  <div className="canva-card p-5">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-semibold text-slate-500 dark:text-zinc-400 uppercase tracking-wider">Active Problems</span>
                      <div className="p-2.5 bg-amber-50 dark:bg-amber-950/40 text-amber-600 dark:text-amber-400 rounded-xl border border-amber-100 dark:border-amber-900/30">
                        <AlertCircle size={16} />
                      </div>
                    </div>
                    <p className="text-3xl font-bold font-display text-amber-600 dark:text-amber-400 mt-1">{activeReports}</p>
                    <span className="text-[10px] text-zinc-500 dark:text-zinc-400 font-bold block mt-1.5">Pending municipal validation</span>
                  </div>

                  <div className="canva-card p-5">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-semibold text-slate-500 dark:text-zinc-400 uppercase tracking-wider">Resolved Cases</span>
                      <div className="p-2.5 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 rounded-xl border border-emerald-100 dark:border-emerald-900/30">
                        <CheckCircle2 size={16} />
                      </div>
                    </div>
                    <p className="text-3xl font-bold font-display text-emerald-600 dark:text-emerald-400 mt-1">{resolvedReports}</p>
                    <span className="text-[10px] text-zinc-500 dark:text-zinc-400 font-bold block mt-1.5">Successfully closed with audits</span>
                  </div>

                  <div className="canva-card p-5">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-semibold text-slate-500 dark:text-zinc-400 uppercase tracking-wider">Critical Hazards</span>
                      <div className="p-2.5 bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 rounded-xl border border-rose-100 dark:border-rose-900/30">
                        <AlertTriangle size={16} />
                      </div>
                    </div>
                    <p className="text-3xl font-bold font-display text-rose-600 dark:text-rose-400 mt-1">{criticalCount}</p>
                    <span className="text-[10px] text-zinc-500 dark:text-zinc-400 font-bold block mt-1.5">Emergency dispatch active</span>
                  </div>
                </div>

                {/* AI PREDICTIVE HOTSPOTS & SEASONAL PREDICTIONS */}
                {predictive && (
                  <div className="bg-gradient-to-br from-violet-950 via-indigo-950 to-slate-950 text-white rounded-3xl p-6 shadow-xl relative overflow-hidden border border-violet-800/30">
                    <div className="absolute right-0 bottom-0 opacity-5 pointer-events-none transform translate-y-4">
                      <Zap size={240} className="text-violet-400" />
                    </div>
                    
                    <div className="flex flex-col md:flex-row md:items-center justify-between mb-4">
                      <div className="flex items-center space-x-2.5">
                        <div className="bg-violet-600/30 text-violet-300 p-2.5 rounded-xl border border-violet-500/20">
                          <Activity size={20} className="animate-pulse" />
                        </div>
                        <div>
                          <h3 className="font-display font-black text-lg text-white">AI Community Health &amp; Predictions</h3>
                          <p className="text-xs text-violet-300 font-mono font-bold uppercase">Powered by Gemini AI Engine Insights</p>
                        </div>
                      </div>
                      <div className="mt-2 md:mt-0 bg-white/10 text-white px-4 py-2 rounded-xl border border-white/10 flex items-center space-x-2 font-bold text-xs">
                        <span>Ward Score:</span>
                        <span className="font-mono font-bold text-sm text-violet-300 bg-black/40 px-2.5 py-0.5 rounded-lg border border-violet-500/30">{predictive.communityHealthScore}/100</span>
                      </div>
                    </div>

                    <p className="text-sm text-zinc-200 leading-relaxed mb-4 bg-white/5 p-4 rounded-xl border border-white/5 font-sans italic">
                      "{predictive.generalInsight}"
                    </p>

                    <h4 className="text-xs font-bold tracking-wider uppercase text-violet-300 mb-2.5">Predictive Infrastructure Risk Analysis:</h4>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                      {predictive.hotspots.map((hot, idx) => (
                        <div key={hot.id} className="bg-white/5 p-4 rounded-xl border border-white/5 text-xs hover:bg-white/10 transition-colors">
                          <div className="flex items-center justify-between mb-1.5">
                            <span className="font-bold text-violet-300">{hot.area}</span>
                            <span className="bg-gradient-to-r from-violet-600 to-indigo-600 text-white font-mono font-bold px-2 py-0.5 rounded-lg text-[10px] shadow-sm">
                              Risk: {hot.riskScore}%
                            </span>
                          </div>
                          <p className="text-[11px] text-zinc-400 italic mb-2">Predicted Category: {getCategoryLabel(hot.predictedCategory)}</p>
                          <p className="text-zinc-200 leading-snug">{hot.riskReason}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* TWO COLUMN ROW: RECENT HAZARDS & COMMUNITY LEADERS */}
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                  {/* Left: Recent reports with quick click to explore */}
                  <div className="lg:col-span-7 space-y-4">
                    <div className="flex items-center justify-between">
                      <h3 className="font-display font-black text-lg text-slate-800 dark:text-white uppercase tracking-tight">Active Local Hazard Alerts</h3>
                      <button
                        onClick={() => setActiveTab("explore")}
                        className="text-xs font-bold text-violet-600 dark:text-violet-400 hover:text-white hover:bg-violet-600 dark:hover:bg-violet-600 bg-violet-50 dark:bg-violet-950/40 px-3 py-1.5 rounded-xl border border-violet-200 dark:border-violet-900/40 transition-all flex items-center space-x-1 shadow-sm"
                      >
                        <span>View All Feed</span>
                        <ChevronRight size={14} />
                      </button>
                    </div>

                    <div className="space-y-4">
                      {issues.slice(0, 3).map(issue => {
                        const sev = getSeverityColor(issue.severity);
                        return (
                          <div
                            key={issue.id}
                            className="canva-card p-4 flex items-start space-x-4 hover:border-violet-400 dark:hover:border-violet-500 transition-all cursor-pointer group"
                            onClick={() => {
                              setSelectedIssue(issue);
                              setActiveTab("explore");
                            }}
                          >
                            {isVideoUrl(issue.imageUrl) ? (
                              <video
                                src={issue.imageUrl}
                                className="w-16 h-16 rounded-xl object-cover bg-slate-100 shrink-0 border border-slate-200/60 dark:border-zinc-700/60"
                                muted
                                playsInline
                                preload="metadata"
                              />
                            ) : (
                              <img
                                src={issue.imageUrl}
                                alt={issue.title}
                                className="w-16 h-16 rounded-xl object-cover bg-slate-100 shrink-0 border border-slate-200/60 dark:border-zinc-700/60"
                              />
                            )}
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center justify-between mb-1">
                                <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full border border-slate-200/40 dark:border-zinc-700/40 ${sev.bg || "bg-yellow-400"} ${sev.text || "text-black"}`}>
                                  {issue.severity} Severity
                                </span>
                                <span className="text-[10px] text-zinc-500 dark:text-zinc-400 font-mono font-medium">
                                  {new Date(issue.reportedAt).toLocaleDateString()}
                                </span>
                              </div>
                              <h4 className="font-bold text-base text-slate-900 dark:text-slate-100 group-hover:text-violet-600 dark:group-hover:text-violet-400 truncate transition-colors">
                                {issue.title}
                              </h4>
                              <p className="text-zinc-500 dark:text-slate-400 text-xs truncate mt-0.5 font-medium">
                                {issue.description}
                              </p>
                              <div className="flex items-center space-x-2 mt-2">
                                <span className="text-[11px] bg-slate-50 dark:bg-slate-800 border border-slate-100 dark:border-zinc-700/60 px-2.5 py-0.5 rounded-full text-slate-600 dark:text-slate-300 font-bold">
                                  {getCategoryLabel(issue.category)}
                                </span>
                                <span className="text-[10px] text-violet-700 dark:text-violet-300 font-semibold bg-violet-50 dark:bg-violet-950/60 px-2.5 py-0.5 rounded-full border border-violet-100 dark:border-violet-900/30">
                                  Status: {issue.status}
                                </span>
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* Right: Success story highlights & Top Leaders */}
                  <div className="lg:col-span-5 space-y-4">
                    <div className="canva-card p-5">
                      <h3 className="font-display font-black text-md text-slate-800 dark:text-white mb-3 flex items-center space-x-2 uppercase tracking-tight">
                        <Award className="text-emerald-500" size={18} />
                        <span>Recent Ward Success Story</span>
                      </h3>
                      <div className="p-4 bg-emerald-50/60 dark:bg-emerald-950/10 rounded-2xl border border-emerald-100 dark:border-emerald-900/30 text-xs shadow-sm shadow-emerald-500/5">
                        <p className="font-bold text-emerald-900 dark:text-emerald-400 mb-1 flex items-center gap-1">
                          🎉 Broadway Safety Guardrail Restored!
                        </p>
                        <p className="text-zinc-700 dark:text-slate-300 leading-relaxed font-medium">
                          Within 6 days of the initial citizen report, and supported by 45 community upvotes, District 4 Steel Construction Crew fully rebuilt the safety barrier. Pedestrians are now completely secure.
                        </p>
                        <span className="text-[10px] text-zinc-500 dark:text-slate-400 font-mono block mt-2 font-bold text-right">
                          Completed: June 23, 2026
                        </span>
                      </div>
                    </div>

                    {/* Miniature Leaderboard */}
                    <div className="canva-card p-5">
                      <div className="flex items-center justify-between mb-3.5">
                        <h3 className="font-display font-black text-md text-slate-800 dark:text-white flex items-center space-x-2 uppercase tracking-tight">
                          <Users size={18} className="text-violet-500" />
                          <span>Ward Hero Board</span>
                        </h3>
                        <button
                          onClick={() => setActiveTab("leaderboard")}
                          className="text-xs text-violet-600 dark:text-violet-400 hover:text-white hover:bg-violet-600 bg-violet-50 dark:bg-violet-950/40 px-3 py-1.5 rounded-xl border border-violet-200 dark:border-violet-900/40 transition-all font-bold shadow-sm"
                        >
                          All Leaders
                        </button>
                      </div>
                      <div className="space-y-3">
                        {leaderboard.slice(0, 3).map((lead, idx) => (
                          <div key={lead.userId} className="flex items-center justify-between text-xs p-2 bg-slate-50 dark:bg-zinc-800/40 border border-slate-100 dark:border-zinc-800 rounded-xl hover:border-violet-300 transition-all">
                            <div className="flex items-center space-x-2.5">
                              <span className="font-bold text-slate-400 dark:text-zinc-500 w-4">{idx + 1}.</span>
                              <img
                                src={lead.avatar}
                                alt={lead.name}
                                className="w-8 h-8 rounded-full object-cover border border-slate-200 dark:border-zinc-700"
                              />
                              <div>
                                <p className="font-bold text-slate-800 dark:text-white">{lead.name}</p>
                                <p className="text-[10px] text-zinc-500 dark:text-slate-400 font-medium">Reports: {lead.reportsCount}</p>
                              </div>
                            </div>
                            <span className="font-mono font-bold text-violet-700 dark:text-violet-300 bg-violet-50 dark:bg-violet-950/60 px-2.5 py-0.5 rounded-full border border-violet-100 dark:border-violet-900/30 text-[10px]">
                              {lead.points} pts
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* 2. EXPLORE FEED PAGE & DETAIL DIALOG */}
            {activeTab === "explore" && (
              <div className="space-y-6">
                
                {/* FILTER CONTROLS BAR */}
                <div className="canva-card p-4 flex flex-wrap items-center justify-between gap-4">
                  <div className="flex flex-wrap items-center gap-2.5">
                    <div className="flex items-center space-x-1.5 bg-violet-600 text-white px-3 py-1.5 rounded-xl text-xs font-bold border border-violet-500/10">
                      <Filter size={14} />
                      <span>Filter Categories:</span>
                    </div>
                    <select
                      value={filterCategory}
                      onChange={(e) => setFilterCategory(e.target.value)}
                      className="bg-slate-50 dark:bg-zinc-900 text-xs px-3 py-2 rounded-xl border border-slate-200 dark:border-zinc-800 outline-none focus:ring-2 focus:ring-violet-500/25 text-slate-800 dark:text-zinc-200 font-bold"
                    >
                      <option value="all">All Categories</option>
                      <option value="potholes">🕳️ Potholes</option>
                      <option value="water_leakages">💧 Water Leakages</option>
                      <option value="garbage_accumulation">🗑️ Garbage Accumulation</option>
                      <option value="broken_streetlights">💡 Broken Streetlights</option>
                      <option value="damaged_infrastructure">🚧 Damaged Infrastructure</option>
                      <option value="road_hazards">⚠️ Road Hazards</option>
                    </select>

                    <select
                      value={filterStatus}
                      onChange={(e) => setFilterStatus(e.target.value)}
                      className="bg-slate-50 dark:bg-zinc-900 text-xs px-3 py-2 rounded-xl border border-slate-200 dark:border-zinc-800 outline-none focus:ring-2 focus:ring-violet-500/25 text-slate-800 dark:text-zinc-200 font-bold"
                    >
                      <option value="all">All States</option>
                      <option value="Reported">Reported</option>
                      <option value="Under Verification">Under Verification</option>
                      <option value="Assigned">Assigned</option>
                      <option value="In Progress">In Progress</option>
                      <option value="Resolved">Resolved</option>
                    </select>
                  </div>
                </div>

                {/* TWO SPLIT DISPLAY (FEED ON THE LEFT, SELECTED DETAILS IN FLOATING WINDOW / OVERLAY) */}
                <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
                  
                  {/* FEED CONTAINER */}
                  <div className="xl:col-span-6 space-y-4">
                    {issues.filter(issue => {
                      if (filterCategory !== "all" && issue.category !== filterCategory) return false;
                      if (filterStatus !== "all" && issue.status !== filterStatus) return false;
                      return true;
                    }).length === 0 ? (
                      <div className="canva-card p-12 text-center">
                        <HelpCircle size={48} className="mx-auto text-slate-400 dark:text-slate-600 mb-3 animate-bounce" />
                        <p className="font-bold text-slate-800 dark:text-white">No reported issues found</p>
                        <p className="text-xs text-slate-500 dark:text-zinc-400 font-semibold mt-1">Try adjusting your category or lifecycle filters above.</p>
                      </div>
                    ) : (
                      issues.filter(issue => {
                        if (filterCategory !== "all" && issue.category !== filterCategory) return false;
                        if (filterStatus !== "all" && issue.status !== filterStatus) return false;
                        return true;
                      }).map(issue => {
                        const sev = getSeverityColor(issue.severity);
                        const isSelected = selectedIssue?.id === issue.id;

                        return (
                          <div
                            key={issue.id}
                            className={`rounded-2xl border p-5 transition-all cursor-pointer flex flex-col justify-between shadow-sm hover:shadow-md ${
                              isSelected
                                ? "bg-violet-500/5 border-violet-500 ring-2 ring-violet-500/20"
                                : "bg-white dark:bg-zinc-900 border-slate-200/60 dark:border-zinc-800 hover:border-violet-400 dark:hover:border-violet-500"
                            }`}
                            onClick={() => setSelectedIssue(issue)}
                          >
                            <div className="flex items-start justify-between space-x-4">
                              <div className="flex items-start space-x-3.5">
                                {isVideoUrl(issue.imageUrl) ? (
                                  <video
                                    src={issue.imageUrl}
                                    className="w-16 h-16 rounded-xl object-cover bg-slate-100 border border-slate-200/60 dark:border-zinc-800 shrink-0"
                                    muted
                                    playsInline
                                    preload="metadata"
                                  />
                                ) : (
                                  <img
                                    src={issue.imageUrl}
                                    alt={issue.title}
                                    className="w-16 h-16 rounded-xl object-cover bg-slate-100 border border-slate-200/60 dark:border-zinc-800"
                                  />
                                )}
                                <div>
                                  <div className="flex items-center space-x-2">
                                    <span className="text-[9px] bg-violet-50 dark:bg-violet-950/60 text-violet-700 dark:text-violet-300 font-bold uppercase px-2 py-0.5 rounded-lg border border-violet-100 dark:border-violet-900/30">
                                      {getCategoryLabel(issue.category)}
                                    </span>
                                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border border-slate-200/40 dark:border-zinc-700/40 ${sev.bg || "bg-yellow-400"} ${sev.text || "text-black"}`}>
                                      {issue.severity} Severity
                                    </span>
                                  </div>
                                  <h4 className="font-bold text-base text-slate-900 dark:text-slate-100 mt-2 leading-snug">
                                    {issue.title}
                                  </h4>
                                  <div className="flex items-center space-x-1.5 text-[10px] text-zinc-500 dark:text-slate-400 font-bold mt-1">
                                    <span>By {issue.reporterName}</span>
                                    <span>•</span>
                                    <span>{new Date(issue.reportedAt).toLocaleDateString()}</span>
                                  </div>
                                </div>
                              </div>
                              <div className="text-right">
                                <span className="text-[10px] font-bold px-2.5 py-1 rounded-xl border border-violet-200 dark:border-violet-900 bg-violet-50 dark:bg-violet-950/60 text-violet-700 dark:text-violet-300 shadow-sm">
                                  {issue.status}
                                </span>
                                <div className="text-[10px] text-zinc-500 dark:text-slate-400 font-mono font-bold mt-2">
                                  Confidence: {issue.verificationConfidence}%
                                </div>
                              </div>
                            </div>

                            <p className="text-xs text-zinc-600 dark:text-slate-300 font-bold mt-3 line-clamp-2 leading-relaxed">
                              {issue.description}
                            </p>

                            <div className="flex items-center justify-between border-t border-slate-100 dark:border-slate-800/80 pt-3.5 mt-4">
                              <div className="flex items-center space-x-3 text-xs text-zinc-500 dark:text-slate-400 font-bold">
                                <span className="flex items-center space-x-1">
                                  <Heart size={14} className="text-rose-500 fill-rose-500" />
                                  <span>{issue.upvotes} validations</span>
                                </span>
                                <span className="flex items-center space-x-1">
                                  <MessageSquare size={14} className="text-violet-500" />
                                  <span>{issue.comments.length} replies</span>
                                </span>
                              </div>
                              
                              <button
                                onClick={() => setSelectedIssue(issue)}
                                className="text-xs font-bold text-white bg-gradient-to-r from-violet-600 to-indigo-600 px-3.5 py-1.5 rounded-xl hover:from-violet-700 hover:to-indigo-700 shadow-md shadow-violet-500/10 hover:shadow-lg transition-all flex items-center space-x-1"
                              >
                                <span>Inspect Details</span>
                                <ChevronRight size={14} />
                              </button>
                            </div>
                          </div>
                        );
                      })
                    )}
                  </div>

                  {/* SELECTED DETAILS DIALOG (IN-LINE ON DESKTOP FOR AMAZING CONTEXT VIEW) */}
                  <div className="xl:col-span-6">
                    {selectedIssue ? (
                      <div className="bg-white dark:bg-zinc-900 rounded-3xl border border-slate-100 dark:border-zinc-850 shadow-xl p-6 space-y-6">
                        
                        {/* Title and Top Header */}
                        <div className="flex items-start justify-between">
                          <div>
                            <div className="flex flex-wrap gap-2 mb-2">
                              <span className="text-xs bg-violet-50 dark:bg-violet-950/60 text-violet-700 dark:text-violet-300 font-semibold border border-violet-100 dark:border-violet-900/30 px-2.5 py-1 rounded-lg uppercase">
                                {getCategoryLabel(selectedIssue.category)}
                              </span>
                              <span className={`text-xs font-bold px-2.5 py-1 rounded-full border border-slate-200/40 dark:border-zinc-700/40 ${
                                getSeverityColor(selectedIssue.severity).bg || "bg-yellow-400"
                              } ${getSeverityColor(selectedIssue.severity).text || "text-black"}`}>
                                {selectedIssue.severity} Severity
                              </span>
                            </div>
                            <h3 className="font-display font-black text-xl text-slate-900 dark:text-white leading-snug">
                              {selectedIssue.title}
                            </h3>
                            <p className="text-xs font-mono text-zinc-500 dark:text-zinc-400 mt-1 flex items-center space-x-1 font-bold">
                              <MapPin size={12} className="text-violet-500" />
                              <span>Lat: {selectedIssue.latitude.toFixed(5)}, Lon: {selectedIssue.longitude.toFixed(5)}</span>
                            </p>
                          </div>
                          <button
                            onClick={() => setSelectedIssue(null)}
                            className="p-1.5 bg-slate-100 dark:bg-zinc-800 hover:bg-slate-200 dark:hover:bg-zinc-700 rounded-xl text-slate-500 dark:text-slate-400 transition-colors border border-slate-200/60 dark:border-zinc-700/60"
                          >
                            <X size={18} />
                          </button>
                        </div>

                        {/* Large Image Showcase */}
                        <div className="relative h-48 rounded-2xl overflow-hidden bg-slate-100 dark:bg-zinc-900 border border-slate-200/60 dark:border-zinc-800 shadow-inner">
                          {isVideoUrl(selectedIssue.imageUrl) ? (
                            <video
                              src={selectedIssue.imageUrl}
                              controls
                              className="w-full h-full object-cover animate-fade-in"
                            />
                          ) : (
                            <img
                              src={selectedIssue.imageUrl}
                              alt={selectedIssue.title}
                              className="w-full h-full object-cover"
                            />
                          )}
                          <div className="absolute top-3 right-3 bg-slate-900/90 backdrop-blur-md text-violet-300 px-3 py-1 rounded-full font-mono text-[10px] font-bold border border-white/10 uppercase">
                            Urgency rating: {selectedIssue.urgencyScore}/100
                          </div>
                        </div>

                        {/* Description & Action details */}
                        <div className="space-y-4">
                          <div>
                            <h4 className="text-xs font-semibold text-slate-400 dark:text-zinc-400 uppercase tracking-wider mb-1">Issue Description</h4>
                            <p className="text-xs text-slate-600 dark:text-zinc-300 leading-relaxed font-sans bg-slate-50 dark:bg-zinc-950 p-4 rounded-2xl border border-slate-100 dark:border-zinc-900 font-medium">
                              {selectedIssue.description}
                            </p>
                          </div>

                          <div>
                            <h4 className="text-xs font-semibold text-slate-400 dark:text-zinc-400 uppercase tracking-wider mb-1">AI Recommended Action Plan</h4>
                            <p className="text-xs text-violet-800 dark:text-violet-200 leading-relaxed font-sans bg-violet-50 dark:bg-violet-950/40 p-4 rounded-2xl border border-violet-100/60 dark:border-violet-900/40 font-bold">
                              🔧 {selectedIssue.suggestedAction}
                            </p>
                          </div>
                        </div>

                        {/* COMMUNITY VERIFICATION AREA */}
                        <div className="bg-gradient-to-br from-violet-600 to-indigo-600 text-white p-5 rounded-2xl shadow-lg shadow-violet-500/10 border border-violet-500/20">
                          <div className="flex items-center justify-between mb-3">
                            <div>
                              <h4 className="text-xs font-bold uppercase tracking-tight">Community Verification Engine</h4>
                              <p className="text-[10px] font-bold text-violet-100">Validate reports to elevate municipal scheduling priority.</p>
                            </div>
                            <div className="text-right bg-white/10 backdrop-blur-md px-2.5 py-1 rounded-xl border border-white/10">
                              <span className="text-sm font-bold font-mono text-white block">{selectedIssue.verificationConfidence}%</span>
                              <span className="text-[8px] text-violet-200 uppercase font-bold block">confidence</span>
                            </div>
                          </div>

                          {/* Upvote & Downvote Button Actions */}
                          <div className="flex">
                            <button
                              onClick={() => verifyIssue(selectedIssue.id, true)}
                              disabled={isCastingVote || selectedIssue.verifications.some(v => v.userId === user?.id)}
                              className="flex-1 bg-white dark:bg-slate-900 hover:bg-slate-100 dark:hover:bg-slate-800 text-violet-600 dark:text-violet-300 py-3 rounded-xl text-xs font-bold flex items-center justify-center space-x-1.5 transition-all disabled:opacity-50 shadow-md shadow-black/5 hover:scale-[1.01]"
                            >
                              <Heart size={14} className="text-rose-500 fill-rose-500" />
                              <span>Upvote / Confirm (Earn +15)</span>
                            </button>
                          </div>
                        </div>

                        {/* LIFECYCLE TIMELINE TRACKING */}
                        <div>
                          <h4 className="text-xs font-semibold text-slate-400 dark:text-zinc-400 uppercase tracking-wider mb-3.5">Lifecycle Operations Timeline</h4>
                          <div className="relative border-l-2 border-slate-200 dark:border-zinc-800 pl-4 ml-1 space-y-4">
                            {selectedIssue.timeline.map((item, idx) => (
                              <div key={idx} className="relative">
                                <span className="absolute -left-[21px] top-1.5 w-3 h-3 rounded-full bg-violet-500 border-2 border-white dark:border-zinc-900 shadow-sm"></span>
                                <div className="text-xs bg-slate-50 dark:bg-zinc-850/40 p-3.5 rounded-2xl border border-slate-100 dark:border-zinc-800 hover:border-violet-300 dark:hover:border-violet-700 transition-all">
                                  <p className="font-bold text-slate-800 dark:text-white uppercase text-[11px]">{item.status}</p>
                                  <p className="text-zinc-500 dark:text-slate-300 text-[11px] mt-0.5 font-medium">{item.notes}</p>
                                  <span className="text-[9px] text-zinc-400 dark:text-slate-400 font-mono font-medium block mt-1">
                                    By {item.updatedBy} • {new Date(item.updatedAt).toLocaleTimeString()}
                                  </span>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>

                        {/* COMPLAINT PDF GENERATION AND EXPORT */}
                        <div className="flex gap-2">
                          <button
                            onClick={() => generateOfficialReportDoc(selectedIssue.id)}
                            disabled={generatingReportId === selectedIssue.id}
                            className="flex-1 py-3 px-4 rounded-xl bg-slate-900 hover:bg-black text-white font-bold text-xs flex items-center justify-center space-x-2 border border-slate-800 disabled:opacity-50 shadow-md transition-all hover:scale-[1.01]"
                          >
                            {generatingReportId === selectedIssue.id ? (
                              <>
                                <Loader2 size={14} className="animate-spin" />
                                <span>AI Drafting Outline...</span>
                              </>
                            ) : (
                              <>
                                <FileText size={14} />
                                <span>Generate Official Report</span>
                              </>
                            )}
                          </button>
                        </div>

                        {/* COMMUNITY DISCUSSION / DISCUSS FEED */}
                        <div className="space-y-3.5 border-t border-slate-100 dark:border-zinc-800/80 pt-5">
                          <h4 className="text-xs font-semibold text-slate-400 dark:text-zinc-400 uppercase tracking-wider flex items-center space-x-1.5">
                            <MessageSquare size={14} />
                            <span>Community Discussions ({selectedIssue.comments.length})</span>
                          </h4>

                          <div className="space-y-2.5 max-h-48 overflow-y-auto pr-1">
                            {selectedIssue.comments.length === 0 ? (
                              <p className="text-xs text-zinc-500 dark:text-slate-400 font-bold italic text-center py-2">No comments yet. Start the conversation!</p>
                            ) : (
                              selectedIssue.comments.map(comment => (
                                <div key={comment.id} className="p-3 rounded-xl bg-slate-50 dark:bg-zinc-950/40 border border-slate-100 dark:border-zinc-800 text-xs">
                                  <div className="flex items-center justify-between mb-1">
                                    <div className="flex items-center space-x-1.5">
                                      <span className="font-bold text-slate-800 dark:text-white">{comment.userName}</span>
                                      {comment.isOfficial && (
                                        <span className="text-[9px] font-bold bg-violet-600 text-white px-2 py-0.5 rounded-full">
                                          Official Dispatch
                                        </span>
                                      )}
                                    </div>
                                    <span className="text-[9px] text-zinc-500 dark:text-slate-400 font-mono font-medium">
                                      {new Date(comment.createdAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                                    </span>
                                  </div>
                                  <p className="text-zinc-600 dark:text-slate-300 leading-relaxed text-[11px] font-medium">
                                    {comment.text}
                                  </p>
                                </div>
                              ))
                            )}
                          </div>

                          {/* Submit Comment Form */}
                          <div className="flex space-x-2">
                            <input
                              type="text"
                              value={commentText}
                              onChange={(e) => setCommentText(e.target.value)}
                              placeholder="Write a constructive civic feedback..."
                              className="flex-1 bg-slate-50 dark:bg-zinc-950 border border-slate-200 dark:border-zinc-800 rounded-xl text-xs px-3.5 py-2.5 outline-none focus:ring-2 focus:ring-violet-500/25 text-slate-800 dark:text-zinc-100 font-medium"
                            />
                            <button
                              onClick={() => submitComment(selectedIssue.id)}
                              className="bg-violet-600 hover:bg-violet-700 text-white p-3 rounded-xl font-bold shrink-0 transition-all shadow-md shadow-violet-500/10"
                            >
                              <Send size={14} />
                            </button>
                          </div>
                        </div>

                      </div>
                    ) : (
                      <div className="bg-white dark:bg-zinc-900 rounded-3xl border border-slate-100 dark:border-zinc-850 shadow-md p-8 text-center text-zinc-500 dark:text-zinc-400">
                        <MapPin size={48} className="mx-auto mb-3 text-violet-500 animate-bounce" />
                        <h4 className="font-bold text-slate-800 dark:text-white uppercase tracking-tight text-base">Hazard Inspection View</h4>
                        <p className="text-xs font-semibold mt-2 text-slate-500 dark:text-zinc-300 leading-relaxed">Select any community report from the map or feed to review technical audits, AI action paths, and community discussions.</p>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* 3. REPORT AN ISSUE PAGE */}
            {activeTab === "report" && (
              <div className="max-w-3xl mx-auto space-y-6">
                
                <div className="bg-white dark:bg-zinc-900 p-8 rounded-3xl border border-slate-100 dark:border-zinc-850 shadow-xl space-y-6">
                  <div>
                    <h3 className="font-display font-black text-xl text-slate-900 dark:text-white uppercase tracking-tight">
                      AI-Assisted Incident Reporter
                    </h3>
                    <p className="text-xs text-zinc-500 dark:text-zinc-400 font-semibold mt-1">
                      Take a photo of a local hazard using your camera or upload an image. Gemini Vision will analyze the image, classify the hazard, draft detailed descriptions, analyze risk severity, and formulate suggested action plans instantly.
                    </p>
                  </div>

                  {/* LIVE CAMERA CAPTURE / UPLOAD AREA */}
                  {isCameraActive ? (
                    <div className="relative bg-black rounded-3xl overflow-hidden aspect-video max-w-2xl mx-auto border border-zinc-850 shadow-2xl flex flex-col items-center justify-center">
                      {/* Live Video Element */}
                      <video
                        ref={videoRef}
                        autoPlay
                        playsInline
                        className="w-full h-full object-cover"
                      />
                      
                      {/* Viewfinder overlays */}
                      <div className="absolute inset-0 border-[20px] border-black/40 pointer-events-none flex items-center justify-center">
                        {/* Reticle / Grid */}
                        <div className="w-48 h-48 border border-dashed border-white/30 rounded-full flex items-center justify-center">
                          <div className="w-16 h-16 border border-white/25 rounded-md flex items-center justify-center">
                            <div className="w-1.5 h-1.5 bg-red-500 rounded-full animate-ping"></div>
                          </div>
                        </div>
                      </div>

                      {/* Camera Controls Bar */}
                      <div className="absolute bottom-4 left-4 right-4 bg-slate-900/95 backdrop-blur-md rounded-2xl p-4 border border-zinc-800 flex flex-wrap items-center justify-between gap-3 z-10">
                        {/* Device Selector */}
                        <div className="flex items-center space-x-2">
                          {cameraDevices.length > 1 ? (
                            <div className="flex items-center space-x-1 bg-zinc-950/80 px-2.5 py-1.5 rounded-lg border border-zinc-805">
                              <RefreshCw size={12} className="text-violet-400 animate-spin-slow" />
                              <select
                                value={selectedDeviceId}
                                onChange={(e) => {
                                  setSelectedDeviceId(e.target.value);
                                  startCamera(e.target.value);
                                }}
                                className="bg-transparent text-[10px] text-zinc-300 font-mono focus:outline-none max-w-[120px] overflow-hidden text-ellipsis cursor-pointer"
                              >
                                {cameraDevices.map((device, i) => (
                                  <option key={device.deviceId} value={device.deviceId} className="bg-zinc-950 text-white">
                                    Camera {i + 1} ({device.label.replace(/\(.*\)/, '').trim() || 'Video Input'})
                                  </option>
                                ))}
                              </select>
                            </div>
                          ) : (
                            <span className="text-[10px] text-zinc-400 font-mono flex items-center gap-1">
                              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                              LIVE VIEWPORT
                            </span>
                          )}
                        </div>

                        {/* Shutter capture button */}
                        <button
                          type="button"
                          onClick={capturePhoto}
                          className="px-6 py-2 bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-700 hover:to-rose-700 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 transition-all shadow-lg active:scale-95"
                        >
                          <span className="w-2.5 h-2.5 rounded-full bg-white animate-pulse"></span>
                          TAKE PHOTO
                        </button>

                        {/* Cancel button */}
                        <button
                          type="button"
                          onClick={stopCamera}
                          className="px-4 py-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 font-semibold text-xs rounded-xl transition-all"
                        >
                          Cancel
                        </button>
                      </div>

                      {cameraError && (
                        <div className="absolute top-4 left-4 right-4 bg-red-950/90 text-red-300 border border-red-900/50 p-3 rounded-xl text-[11px] font-mono whitespace-pre-wrap">
                          Error: {cameraError}
                        </div>
                      )}
                    </div>
                  ) : formImage ? (
                    <div className="bg-slate-50 dark:bg-zinc-950/40 p-6 rounded-3xl border border-slate-200 dark:border-zinc-800/80 text-center space-y-4 max-w-2xl mx-auto">
                      <div className="relative inline-block max-w-full">
                        {isVideoUrl(formImage) ? (
                          <video
                            src={formImage}
                            controls
                            className="max-h-64 mx-auto rounded-2xl object-contain border border-slate-200 dark:border-zinc-800 shadow-md"
                          />
                        ) : (
                          <img
                            src={formImage}
                            alt="Incident Report Preview"
                            className="max-h-64 mx-auto rounded-2xl object-contain border border-slate-200 dark:border-zinc-800 shadow-md"
                          />
                        )}
                        <button
                          type="button"
                          onClick={() => setFormImage("")}
                          className="absolute top-3 right-3 p-2 bg-red-600 text-white rounded-full hover:bg-red-700 transition-colors shadow-lg flex items-center justify-center"
                          title="Remove Attachment"
                        >
                          <X size={14} />
                        </button>
                      </div>
                      
                      <div className="flex flex-wrap items-center justify-center gap-3">
                        <button
                          type="button"
                          onClick={() => startCamera()}
                          className="px-5 py-2.5 bg-violet-600 hover:bg-violet-700 text-white font-bold text-xs rounded-xl flex items-center gap-2 transition-all shadow-md shadow-violet-500/10"
                        >
                          <Camera size={14} />
                          Retake Live Photo
                        </button>

                        <div className="relative">
                          <input
                            type="file"
                            accept="image/*,video/*"
                            onChange={handleImageUpload}
                            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                          />
                          <button
                            type="button"
                            className="px-5 py-2.5 bg-white dark:bg-zinc-900 hover:bg-slate-50 dark:hover:bg-zinc-800 text-slate-700 dark:text-zinc-300 font-bold text-xs rounded-xl border border-slate-200 dark:border-zinc-800 transition-all"
                          >
                            Upload Different Image/Video File
                          </button>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="bg-slate-50 dark:bg-zinc-950/40 rounded-3xl p-10 border border-dashed border-violet-200 dark:border-zinc-800/80 max-w-2xl mx-auto text-center space-y-6 flex flex-col items-center justify-center">
                      <div className="w-16 h-16 rounded-2xl bg-violet-100 dark:bg-violet-950/50 flex items-center justify-center text-violet-600 dark:text-violet-400">
                        <Camera size={32} />
                      </div>

                      <div className="space-y-1">
                        <h4 className="font-bold text-slate-800 dark:text-white uppercase tracking-tight text-sm">Capture Incident with Live Camera</h4>
                        <p className="text-xs text-zinc-500 dark:text-zinc-400 max-w-md mx-auto">
                          Allow camera access to instantly frame and take a photo of the public problem. AI will process the video frame or uploaded clip, classify the issue, and autofill the details.
                        </p>
                      </div>

                      <div className="flex flex-col sm:flex-row items-center gap-3 w-full max-w-sm">
                        <button
                          type="button"
                          onClick={() => startCamera()}
                          className="w-full px-5 py-3 bg-violet-600 hover:bg-violet-700 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-2 transition-all shadow-md shadow-violet-500/10 hover:scale-[1.01]"
                        >
                          <Camera size={14} />
                          ACTIVATE LIVE CAMERA
                        </button>

                        <div className="relative w-full">
                          <input
                            type="file"
                            accept="image/*,video/*"
                            onChange={handleImageUpload}
                            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                          />
                          <button
                            type="button"
                            className="w-full px-5 py-3 bg-white dark:bg-zinc-900 hover:bg-slate-50 dark:hover:bg-zinc-800 text-slate-700 dark:text-zinc-300 font-bold text-xs rounded-xl border border-slate-200 dark:border-zinc-800 transition-all flex items-center justify-center gap-1.5"
                          >
                            UPLOAD IMAGE/VIDEO FILE
                          </button>
                        </div>
                      </div>

                      <p className="text-[10px] text-zinc-400 dark:text-slate-500 max-w-sm">
                        Supports automatic detection of potholes, pipeline leakages, public dumps, and structural hazards via images or short video clips.
                      </p>
                    </div>
                  )}

                  {/* Gemini vision analyzing loader */}
                  {analyzingImage && (
                    <div className="p-4 bg-violet-50 dark:bg-violet-950/40 text-violet-700 dark:text-violet-300 rounded-2xl border border-violet-100 dark:border-violet-900/40 flex items-center space-x-3 text-xs font-bold shadow-sm animate-pulse">
                      <Loader2 size={16} className="animate-spin" />
                      <span>Gemini Vision AI is analyzing incident pixels, classifying category, estimating severity, and compiling repair workflows...</span>
                    </div>
                  )}

                  {/* CORE INCIDENT REPORT FORM */}
                  <form onSubmit={submitIssueReport} className="space-y-4 text-black dark:text-white">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-1">
                        <label className="text-xs font-semibold uppercase tracking-wider text-slate-400 dark:text-zinc-500">Issue Title</label>
                        <input
                          type="text"
                          required
                          value={formTitle}
                          onChange={(e) => setFormTitle(e.target.value)}
                          placeholder="e.g. Broken Fire Hydrant Outlet"
                          className="w-full bg-slate-50 dark:bg-zinc-950 border border-slate-200 dark:border-zinc-800 rounded-xl text-xs px-3.5 py-3.5 outline-none focus:ring-2 focus:ring-violet-500/25 font-medium transition-all text-slate-800 dark:text-zinc-200"
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="text-xs font-semibold uppercase tracking-wider text-slate-400 dark:text-zinc-500">Classification Category</label>
                        <select
                          value={formCategory}
                          onChange={(e) => setFormCategory(e.target.value as any)}
                          className="w-full bg-slate-50 dark:bg-zinc-950 border border-slate-200 dark:border-zinc-800 rounded-xl text-xs px-3.5 py-3.5 outline-none focus:ring-2 focus:ring-violet-500/25 font-medium transition-all text-slate-800 dark:text-zinc-200"
                        >
                          <option value="potholes" className="bg-white text-black">🕳️ Potholes &amp; Cracks</option>
                          <option value="water_leakages" className="bg-white text-black">💧 Water Leakages &amp; Pipe Breach</option>
                          <option value="garbage_accumulation" className="bg-white text-black">🗑️ Garbage Accumulation &amp; Dump Sites</option>
                          <option value="broken_streetlights" className="bg-white text-black">💡 Broken Streetlights / Dark Walkways</option>
                          <option value="damaged_infrastructure" className="bg-white text-black">🚧 Damaged Public Infrastructure</option>
                          <option value="road_hazards" className="bg-white text-black">⚠️ Road Hazards &amp; Debris</option>
                        </select>
                      </div>
                    </div>

                    <div className="space-y-1">
                      <label className="text-xs font-semibold uppercase tracking-wider text-slate-400 dark:text-zinc-500">Detailed Analytics Description</label>
                      <textarea
                        rows={3}
                        required
                        value={formDescription}
                        onChange={(e) => setFormDescription(e.target.value)}
                        placeholder="Detail the exact community issue context..."
                        className="w-full bg-slate-50 dark:bg-zinc-950 border border-slate-200 dark:border-zinc-800 rounded-xl text-xs px-3.5 py-3.5 outline-none focus:ring-2 focus:ring-violet-500/25 font-medium transition-all text-slate-800 dark:text-zinc-200"
                      />
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="space-y-1">
                        <label className="text-xs font-semibold uppercase tracking-wider text-slate-400 dark:text-zinc-500">Estimated Severity</label>
                        <select
                          value={formSeverity}
                          onChange={(e) => setFormSeverity(e.target.value as any)}
                          className="w-full bg-slate-50 dark:bg-zinc-950 border border-slate-200 dark:border-zinc-800 rounded-xl text-xs px-3.5 py-3.5 outline-none focus:ring-2 focus:ring-violet-500/25 font-medium transition-all text-slate-800 dark:text-zinc-200"
                        >
                          <option value="Low" className="bg-white text-black">Low (Minor annoyance)</option>
                          <option value="Medium" className="bg-white text-black">Medium (Affects local walkability)</option>
                          <option value="High" className="bg-white text-black">High (Immediate road/structural danger)</option>
                          <option value="Critical" className="bg-white text-black">Critical (Structural failure, high safety hazard)</option>
                        </select>
                      </div>

                      <div className="space-y-1">
                        <label className="text-xs font-semibold uppercase tracking-wider text-slate-400 dark:text-zinc-500">Latitude Coordinate</label>
                        <input
                          type="number"
                          step="any"
                          required
                          value={formLatitude}
                          onChange={(e) => setFormLatitude(Number(e.target.value))}
                          className="w-full bg-slate-50 dark:bg-zinc-950 border border-slate-200 dark:border-zinc-800 rounded-xl text-xs px-3.5 py-3.5 outline-none focus:ring-2 focus:ring-violet-500/25 font-mono font-medium transition-all text-slate-800 dark:text-zinc-200"
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="text-xs font-semibold uppercase tracking-wider text-slate-400 dark:text-zinc-500">Longitude Coordinate</label>
                        <input
                          type="number"
                          step="any"
                          required
                          value={formLongitude}
                          onChange={(e) => setFormLongitude(Number(e.target.value))}
                          className="w-full bg-slate-50 dark:bg-zinc-950 border border-slate-200 dark:border-zinc-800 rounded-xl text-xs px-3.5 py-3.5 outline-none focus:ring-2 focus:ring-violet-500/25 font-mono font-medium transition-all text-slate-800 dark:text-zinc-200"
                        />
                      </div>
                    </div>

                    <button
                      type="submit"
                      disabled={isSubmittingReport}
                      className="w-full py-4 rounded-xl bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-700 hover:to-indigo-700 text-white font-bold text-xs uppercase tracking-wider flex items-center justify-center space-x-2 shadow-lg shadow-violet-500/20 transition-all disabled:opacity-50"
                    >
                      {isSubmittingReport ? (
                        <>
                          <Loader2 size={16} className="animate-spin" />
                          <span>Submitting Civic Report...</span>
                        </>
                      ) : (
                        <>
                          <CheckCircle2 size={16} />
                          <span>Submit Report (+50 points)</span>
                        </>
                      )}
                    </button>
                  </form>
                </div>

              </div>
            )}

            {/* 4. PULSE AI CHATBOT PORTAL */}
            {activeTab === "chatbot" && (
              <div className="max-w-4xl mx-auto flex flex-col h-[calc(100vh-12rem)] min-h-[480px] text-black dark:text-white">
                
                {/* Chat header info */}
                <div className="bg-white dark:bg-zinc-900 border border-slate-100 dark:border-zinc-850 rounded-t-3xl p-5 flex items-center justify-between border-b-0 shadow-sm z-10">
                  <div className="flex items-center space-x-2.5">
                    <div className="w-10 h-10 rounded-full bg-violet-100 dark:bg-violet-950/60 flex items-center justify-center text-violet-600 dark:text-violet-300 font-bold relative border border-violet-200/40 dark:border-violet-800/40 shadow-sm">
                      P
                      <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-emerald-500 rounded-full border-2 border-white dark:border-zinc-900"></span>
                    </div>
                    <div>
                      <h3 className="font-display font-black text-sm uppercase text-slate-800 dark:text-white">Pulse AI Civic Assistant</h3>
                      <p className="text-[10px] font-semibold text-zinc-400 dark:text-zinc-500">Deep Insights on Ward Hazards &amp; Predictive Action Plans</p>
                    </div>
                  </div>
                  <span className="text-[10px] font-mono bg-violet-50 dark:bg-violet-950/60 text-violet-600 dark:text-violet-300 px-3 py-1 rounded-full font-bold border border-violet-100 dark:border-violet-900/30 uppercase">
                    Gemini Connected
                  </span>
                </div>

                {/* Messages list container */}
                <div className="flex-1 bg-slate-50 dark:bg-zinc-950/40 border-x border-slate-100 dark:border-zinc-850 p-6 overflow-y-auto space-y-4">
                  {chatMessages.map(msg => (
                    <div
                      key={msg.id}
                      className={`flex ${msg.sender === "user" ? "justify-end" : "justify-start"}`}
                    >
                      <div className={`max-w-[80%] rounded-2xl p-4 text-xs font-semibold ${
                        msg.sender === "user"
                          ? "bg-violet-600 text-white rounded-tr-none shadow-md shadow-violet-500/10"
                          : "bg-white dark:bg-zinc-900 text-slate-800 dark:text-slate-100 rounded-tl-none border border-slate-100 dark:border-zinc-800 shadow-sm"
                      }`}>
                        {/* Text Render with simplistic bold formatting */}
                        <p className="leading-relaxed whitespace-pre-line font-sans">
                          {msg.text.split("**").map((part, idx) => (idx % 2 === 1 ? <strong key={idx} className="font-bold text-yellow-300 dark:text-violet-300">{part}</strong> : part))}
                        </p>
                        <span className={`text-[9px] block mt-1.5 text-right font-mono font-medium ${msg.sender === "user" ? "text-violet-200" : "text-zinc-400"}`}>
                          {msg.timestamp}
                        </span>
                      </div>
                    </div>
                  ))}
                  {chatLoading && (
                    <div className="flex justify-start">
                      <div className="bg-white dark:bg-zinc-900 text-slate-600 dark:text-zinc-400 rounded-2xl p-4 border border-slate-100 dark:border-zinc-800 flex items-center space-x-2 text-xs font-semibold shadow-sm">
                        <Loader2 size={14} className="animate-spin text-violet-600" />
                        <span className="animate-pulse">Pulse AI is thinking...</span>
                      </div>
                    </div>
                  )}
                </div>

                {/* Preset quick actions / queries */}
                <div className="bg-slate-50 dark:bg-zinc-950/40 border-x border-slate-100 dark:border-zinc-850 p-3.5 flex gap-2 overflow-x-auto whitespace-nowrap scrollbar-none">
                  {[
                    { text: "Show nearby unresolved issues", label: "🗺️ Nearby Issues" },
                    { text: "Summarize local area problems", label: "📊 Area Summary" },
                    { text: "Explain issue trends", label: "📈 Trend Analysis" },
                    { text: "How do I earn badges?", label: "🏆 Badges Help" },
                  ].map((preset, idx) => (
                    <button
                      key={idx}
                      onClick={() => handleChatSend(preset.text)}
                      className="bg-white dark:bg-zinc-900 hover:bg-violet-50 dark:hover:bg-violet-950/20 text-slate-600 dark:text-slate-300 hover:text-violet-600 dark:hover:text-violet-300 px-4 py-2 rounded-xl text-xs font-semibold border border-slate-200/80 dark:border-zinc-800 transition-all shrink-0 shadow-sm"
                    >
                      {preset.label}
                    </button>
                  ))}
                </div>

                {/* Send Chat form input */}
                <div className="bg-white dark:bg-zinc-900 border border-slate-100 dark:border-zinc-850 border-t-0 rounded-b-3xl p-4 flex space-x-2 shadow-sm">
                  <input
                    type="text"
                    value={chatInput}
                    onChange={(e) => setChatInput(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && handleChatSend()}
                    placeholder="Ask Pulse AI about any municipal topic, hotspot warnings, or priorities..."
                    className="flex-1 bg-slate-50 dark:bg-zinc-950 border border-slate-200 dark:border-zinc-800 rounded-xl text-xs px-4 py-3 outline-none focus:ring-2 focus:ring-violet-500/25 font-semibold text-slate-800 dark:text-zinc-100"
                  />
                  <button
                    onClick={() => handleChatSend()}
                    className="bg-violet-600 hover:bg-violet-700 text-white p-3.5 rounded-xl shadow-md shadow-violet-500/10 font-bold shrink-0 transition-all hover:scale-[1.02]"
                  >
                    <Send size={16} />
                  </button>
                </div>

              </div>
            )}

            {/* 5. LEADERBOARD & BADGES PAGE */}
            {activeTab === "leaderboard" && (
              <div className="space-y-6 text-black dark:text-white">
                
                {/* Gamification progress overview card */}
                {user && (
                  <div className="bg-white dark:bg-zinc-900 rounded-3xl border border-slate-100 dark:border-zinc-850 p-8 shadow-xl grid grid-cols-1 md:grid-cols-3 gap-6 items-center">
                    <div className="space-y-2">
                      <h3 className="font-display font-bold text-xl text-slate-900 dark:text-white uppercase tracking-tight">
                        Your Citizen Reputation
                      </h3>
                      <p className="text-xs text-zinc-500 dark:text-zinc-400 font-medium">
                        Earn points by logging unresolved hazards, verifying community complaints, and answering discussion feeds constructivly.
                      </p>
                      <div className="flex items-center space-x-2 mt-4">
                        <span className="text-xs bg-violet-50 dark:bg-violet-950/60 text-violet-700 dark:text-violet-300 px-2.5 py-1 rounded-full font-bold border border-violet-100 dark:border-violet-900/40 uppercase tracking-wider">
                          Level {Math.floor(user.points / 100) + 1} Citizen
                        </span>
                        <span className="text-xs font-semibold text-slate-600 dark:text-violet-400">
                          {user.points} total points
                        </span>
                      </div>
                    </div>

                    <div className="space-y-2.5">
                      <div className="flex items-center justify-between text-xs font-semibold text-slate-400">
                        <span className="uppercase tracking-tight">Next Level Progress</span>
                        <span className="font-mono font-bold text-violet-600 dark:text-violet-400">{user.points % 100} / 100 pts</span>
                      </div>
                      <div className="w-full bg-slate-100 dark:bg-zinc-800 h-2.5 rounded-full overflow-hidden">
                        <div
                          className="bg-gradient-to-r from-violet-500 to-indigo-500 h-full rounded-full"
                          style={{ width: `${user.points % 100}%` }}
                        ></div>
                      </div>
                    </div>

                    <div className="bg-gradient-to-br from-violet-600 to-indigo-600 text-white p-5 rounded-2xl text-center shadow-lg shadow-violet-500/15 border border-violet-500/20">
                      <span className="text-[10px] uppercase tracking-wider font-bold text-violet-100">Reputation Score</span>
                      <p className="text-4xl font-display font-black text-white mt-1">{user.reputationScore}%</p>
                      <span className="text-[9px] font-bold uppercase tracking-tight text-violet-200 block mt-1">Peer Verification Verified</span>
                    </div>
                  </div>
                )}

                {/* COMPLETE BADGES LIST SHOWCASE */}
                <div className="bg-white dark:bg-zinc-900 p-8 rounded-3xl border border-slate-100 dark:border-zinc-850 shadow-xl space-y-4 text-black dark:text-white">
                  <h3 className="font-display font-bold text-lg uppercase tracking-tight text-slate-900 dark:text-white">Municipal Contribution Badges</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {badges.map(badge => {
                      const isUnlocked = user?.badges.includes(badge.id);
                      return (
                        <div
                          key={badge.id}
                          className={`p-4 rounded-xl border flex items-start space-x-3 transition-colors ${
                            isUnlocked
                              ? "bg-violet-50/50 dark:bg-violet-950/20 border-violet-100 dark:border-violet-900/40 text-slate-800 dark:text-white"
                              : "bg-slate-50 dark:bg-zinc-950/60 border-slate-200/60 dark:border-zinc-850 opacity-60 text-zinc-400"
                          }`}
                        >
                          <div className={`w-10 h-10 rounded-2xl flex items-center justify-center font-bold text-lg shrink-0 border ${
                            isUnlocked ? "bg-gradient-to-tr from-violet-500 to-indigo-500 border-transparent text-white" : "bg-slate-200 dark:bg-zinc-850 border-slate-300 dark:border-zinc-750 text-zinc-500"
                          }`}>
                            🏆
                          </div>
                          <div>
                            <div className="flex items-center space-x-1.5 flex-wrap gap-1">
                              <h4 className="font-bold text-sm uppercase text-slate-800 dark:text-white">{badge.name}</h4>
                              {isUnlocked ? (
                                <span className="text-[9px] bg-violet-600 text-white px-2 py-0.5 rounded-full font-bold uppercase">
                                  Unlocked
                                </span>
                              ) : (
                                <span className="text-[9px] bg-slate-200 dark:bg-zinc-800 text-slate-500 px-2 py-0.5 rounded-full font-bold uppercase">
                                  Locked
                                </span>
                              )}
                            </div>
                            <p className="text-xs text-zinc-500 dark:text-zinc-400 leading-snug mt-1 font-medium">{badge.description}</p>
                            <span className="text-[10px] text-violet-600 dark:text-violet-400 block mt-2 font-bold">Requires {badge.pointsRequired} pts</span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* DETAILED CITIZENS RANKINGS LEADERBOARD */}
                <div className="bg-white dark:bg-zinc-900 rounded-3xl border border-slate-100 dark:border-zinc-850 shadow-xl overflow-hidden text-black dark:text-white">
                  <div className="p-6 border-b border-slate-100 dark:border-zinc-850 bg-gradient-to-r from-violet-600 to-indigo-600 text-white">
                    <h3 className="font-display font-bold text-lg uppercase tracking-tight">Top Citizen Leaderboard Rankings</h3>
                  </div>

                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse text-xs">
                      <thead>
                        <tr className="bg-slate-50 dark:bg-zinc-950/60 text-slate-400 dark:text-zinc-400 uppercase font-bold text-[10px] tracking-wider border-b border-slate-100 dark:border-zinc-850">
                          <th className="py-3 px-6 w-16 text-center">Rank</th>
                          <th className="py-3 px-6">Citizen Name</th>
                          <th className="py-3 px-6 text-center">Badges</th>
                          <th className="py-3 px-6 text-center">Reports logged</th>
                          <th className="py-3 px-6 text-center">Reputation Score</th>
                          <th className="py-3 px-6 text-right">Contribution Points</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 dark:divide-zinc-850">
                        {leaderboard.map((lead, idx) => {
                          const isCurrentUser = lead.userId === user?.id;
                          return (
                            <tr
                              key={lead.userId}
                              className={`hover:bg-slate-50/50 dark:hover:bg-zinc-950/20 transition-colors ${
                                isCurrentUser ? "bg-violet-50/40 dark:bg-violet-950/10 font-bold border-l-4 border-violet-500 text-slate-800 dark:text-white" : "text-slate-700 dark:text-zinc-300"
                              }`}
                            >
                              <td className="py-4 px-6 text-center font-bold text-slate-400 dark:text-zinc-500 text-sm">#{idx + 1}</td>
                              <td className="py-4 px-6">
                                <div className="flex items-center space-x-3">
                                  <img
                                    src={lead.avatar}
                                    alt={lead.name}
                                    className="w-9 h-9 rounded-full object-cover border border-slate-200 dark:border-zinc-800 shadow-sm"
                                  />
                                  <div>
                                    <p className="font-bold text-slate-800 dark:text-white">{lead.name}</p>
                                    {isCurrentUser && <span className="text-[9px] bg-violet-600 text-white px-2 py-0.5 rounded-full font-bold uppercase tracking-wider block mt-0.5 w-max">Active Session</span>}
                                  </div>
                                </div>
                              </td>
                              <td className="py-4 px-6 text-center font-bold text-zinc-500 dark:text-zinc-400">{lead.badgeCount} Badges</td>
                              <td className="py-4 px-6 text-center font-bold text-zinc-500 dark:text-zinc-400">{lead.reportsCount} Reports</td>
                              <td className="py-4 px-6 text-center">
                                <span className="bg-slate-100 dark:bg-zinc-950 px-2.5 py-1 rounded-full font-mono font-bold text-slate-600 dark:text-violet-400">{lead.reputation}%</span>
                              </td>
                              <td className="py-4 px-6 text-right font-mono font-bold text-slate-700 dark:text-violet-400 text-sm">
                                {lead.points} pts
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>

              </div>
            )}

            {/* 6. ADMIN CONTROL CENTER PANEL */}
            {activeTab === "admin" && user?.role === "admin" && (
              <div className="space-y-6">
                
                {/* Header municipal banner */}
                <div className="bg-slate-900 text-white rounded-3xl border border-zinc-800 p-8 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="bg-violet-500 text-white font-bold text-[10px] uppercase tracking-wider px-2.5 py-0.5 rounded-full flex items-center gap-1">
                        <Shield size={10} /> Official Command Center
                      </span>
                      <span className="text-xs text-violet-300 font-mono font-bold">Operator ID: {user.name}</span>
                    </div>
                    <h3 className="font-display font-black text-2xl uppercase tracking-tight text-white">
                      Municipal Maintenance Control Desk
                    </h3>
                    <p className="text-xs text-zinc-300 max-w-2xl font-bold">
                      Authorized operations to progress lifecycle phases of citizen complaints, dispatch maintenance crews, moderate abusive comments, and manage citizen civic contributions.
                    </p>
                  </div>
                  <div className="flex gap-2 shrink-0">
                    <span className="px-3.5 py-1.5 bg-zinc-950 text-violet-400 rounded-xl text-xs font-mono font-bold flex items-center gap-1.5 border border-zinc-800 shadow-sm">
                      <span className="w-2 h-2 rounded-full bg-violet-400 animate-pulse"></span>
                      DATABASE: SYNCED
                    </span>
                  </div>
                </div>

                {/* Sub-tabs menu */}
                <div className="flex border-b border-slate-100 dark:border-zinc-850 gap-2 overflow-x-auto pb-px">
                  <button
                    onClick={() => {
                      setAdminSubTab("pipeline");
                      setSelectedIssue(null);
                    }}
                    className={`px-4 py-3.5 font-display font-bold text-xs uppercase tracking-wider flex items-center gap-2 border border-b-0 rounded-t-xl transition-all whitespace-nowrap ${
                      adminSubTab === "pipeline"
                        ? "bg-violet-600 text-white border-violet-600 shadow-sm"
                        : "bg-white dark:bg-zinc-950 text-slate-500 border-transparent hover:text-slate-800 dark:hover:text-white"
                    }`}
                  >
                    <CheckSquare size={14} />
                    Report Pipeline & Dispatches ({issues.length})
                  </button>
                  <button
                    onClick={() => {
                      setAdminSubTab("citizens");
                      setSelectedAdminUser(null);
                    }}
                    className={`px-4 py-3.5 font-display font-bold text-xs uppercase tracking-wider flex items-center gap-2 border border-b-0 rounded-t-xl transition-all whitespace-nowrap ${
                      adminSubTab === "citizens"
                        ? "bg-violet-600 text-white border-violet-600 shadow-sm"
                        : "bg-white dark:bg-zinc-950 text-slate-500 border-transparent hover:text-slate-800 dark:hover:text-white"
                    }`}
                  >
                    <Users size={14} />
                    Citizen Registry & Badges ({adminUsers.length})
                  </button>
                  <button
                    onClick={() => setAdminSubTab("insights")}
                    className={`px-4 py-3.5 font-display font-bold text-xs uppercase tracking-wider flex items-center gap-2 border border-b-0 rounded-t-xl transition-all whitespace-nowrap ${
                      adminSubTab === "insights"
                        ? "bg-violet-600 text-white border-violet-600 shadow-sm"
                        : "bg-white dark:bg-zinc-950 text-slate-500 border-transparent hover:text-slate-800 dark:hover:text-white"
                    }`}
                  >
                    <BarChart3 size={14} />
                    Municipal System Analytics
                  </button>
                  <button
                    onClick={() => setAdminSubTab("database")}
                    className={`px-4 py-3.5 font-display font-bold text-xs uppercase tracking-wider flex items-center gap-2 border border-b-0 rounded-t-xl transition-all whitespace-nowrap ${
                      adminSubTab === "database"
                        ? "bg-violet-600 text-white border-violet-600 shadow-sm"
                        : "bg-white dark:bg-zinc-950 text-slate-500 border-transparent hover:text-slate-800 dark:hover:text-white"
                    }`}
                  >
                    <Database size={14} />
                    Firebase DB Explorer
                  </button>
                </div>

                {/* Sub-tab 1: Report Pipeline & Crew Dispatcher */}
                {adminSubTab === "pipeline" && (
                  <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
                    
                    {/* Filter & Listing block */}
                    <div className="xl:col-span-5 space-y-4">
                      
                      {/* Search and interactive filtering panel */}
                      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 shadow-sm space-y-3">
                        <div className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest">
                          Roster Filter Controls
                        </div>
                        <input
                          type="text"
                          placeholder="Search report titles..."
                          value={adminReportSearch}
                          onChange={(e) => setAdminReportSearch(e.target.value)}
                          className="w-full text-xs px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 focus:outline-none focus:ring-1 focus:ring-purple-500"
                        />
                        <div className="grid grid-cols-3 gap-2">
                          <select
                            value={adminReportCategoryFilter}
                            onChange={(e) => setAdminReportCategoryFilter(e.target.value)}
                            className="text-[10px] font-semibold bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded p-1.5 outline-none"
                          >
                            <option value="all">Categories (All)</option>
                            <option value="potholes">Potholes</option>
                            <option value="water_leakages">Water Leaks</option>
                            <option value="garbage_accumulation">Garbage</option>
                            <option value="broken_streetlights">Streetlights</option>
                            <option value="damaged_infrastructure">Damage</option>
                            <option value="road_hazards">Road Hazards</option>
                          </select>
                          
                          <select
                            value={adminReportStatusFilter}
                            onChange={(e) => setAdminReportStatusFilter(e.target.value)}
                            className="text-[10px] font-semibold bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded p-1.5 outline-none"
                          >
                            <option value="all">Statuses (All)</option>
                            <option value="Reported">Reported</option>
                            <option value="Under Verification">Under Verify</option>
                            <option value="Assigned">Assigned</option>
                            <option value="In Progress">In Progress</option>
                            <option value="Resolved">Resolved</option>
                          </select>

                          <select
                            value={adminReportSeverityFilter}
                            onChange={(e) => setAdminReportSeverityFilter(e.target.value)}
                            className="text-[10px] font-semibold bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded p-1.5 outline-none"
                          >
                            <option value="all">Severity (All)</option>
                            <option value="Low">Low</option>
                            <option value="Medium">Medium</option>
                            <option value="High">High</option>
                            <option value="Critical">Critical</option>
                          </select>
                        </div>
                      </div>

                      {/* Filtered lists results */}
                      <div className="space-y-2.5 max-h-[600px] overflow-y-auto pr-1">
                        {issues
                          .filter(i => {
                            const matchSearch = i.title.toLowerCase().includes(adminReportSearch.toLowerCase()) || i.description.toLowerCase().includes(adminReportSearch.toLowerCase());
                            const matchCat = adminReportCategoryFilter === "all" || i.category === adminReportCategoryFilter;
                            const matchStat = adminReportStatusFilter === "all" || i.status === adminReportStatusFilter;
                            const matchSev = adminReportSeverityFilter === "all" || i.severity === adminReportSeverityFilter;
                            return matchSearch && matchCat && matchStat && matchSev;
                          })
                          .map(issue => {
                            const isSel = selectedIssue?.id === issue.id;
                            const severityColor = 
                              issue.severity === "Critical" ? "text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/20" :
                              issue.severity === "High" ? "text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/20" :
                              issue.severity === "Medium" ? "text-yellow-600 dark:text-yellow-400 bg-yellow-400/15 dark:bg-yellow-950/20 border border-yellow-200/40 dark:border-yellow-900/40" :
                              "text-slate-600 dark:text-slate-400 bg-slate-50 dark:bg-slate-950/20";
                            
                            const statusColor =
                              issue.status === "Resolved" ? "bg-emerald-100 text-emerald-800 dark:bg-emerald-950/30 dark:text-emerald-400" :
                              issue.status === "In Progress" ? "bg-orange-100 text-orange-800 dark:bg-orange-950/30 dark:text-orange-400" :
                              issue.status === "Assigned" ? "bg-indigo-100 text-indigo-800 dark:bg-indigo-950/30 dark:text-indigo-400" :
                              issue.status === "Under Verification" ? "bg-yellow-400/20 text-yellow-700 dark:bg-yellow-950/30 dark:text-yellow-400 border border-yellow-200/50 dark:border-yellow-900/50" :
                              "bg-slate-100 text-slate-800 dark:bg-slate-800 dark:text-slate-400";

                            return (
                              <div
                                key={issue.id}
                                className={`p-4 rounded-xl border bg-white dark:bg-slate-900 cursor-pointer shadow-sm transition-all ${
                                  isSel
                                    ? "border-purple-600 ring-2 ring-purple-100 dark:ring-purple-950/30"
                                    : "border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700"
                                }`}
                                onClick={() => {
                                  setSelectedIssue(issue);
                                  setAdminSelectedStatus(issue.status);
                                }}
                              >
                                <div className="flex items-center justify-between gap-2 mb-2">
                                  <div className="flex items-center gap-1.5">
                                    <span className="text-[9px] bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 px-2 py-0.5 rounded font-bold">
                                      {getCategoryLabel(issue.category)}
                                    </span>
                                    <span className={`text-[9px] px-2 py-0.5 rounded font-bold uppercase tracking-wider ${severityColor}`}>
                                      {issue.severity}
                                    </span>
                                  </div>
                                  <span className={`text-[9px] px-2 py-0.5 rounded font-bold uppercase tracking-widest ${statusColor}`}>
                                    {issue.status}
                                  </span>
                                </div>
                                
                                <h4 className="font-semibold text-sm leading-snug text-slate-800 dark:text-slate-100">
                                  {issue.title}
                                </h4>
                                
                                <div className="flex items-center justify-between text-[10px] text-slate-400 dark:text-slate-500 mt-2">
                                  <span>By {issue.reporterName}</span>
                                  <span>Urgency score: <strong className="font-mono text-purple-600 dark:text-purple-400">{issue.urgencyScore}</strong></span>
                                </div>
                              </div>
                            );
                          })}
                      </div>
                    </div>

                    {/* Right-hand Action Console */}
                    <div className="xl:col-span-7">
                      {selectedIssue ? (
                        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-md space-y-6">
                          
                          {/* Issue header card in sidebar */}
                          <div className="flex items-start justify-between gap-4 pb-4 border-b border-slate-100 dark:border-slate-800">
                            <div className="flex items-start gap-4">
                              {selectedIssue.imageUrl && (
                                <div className="w-14 h-14 rounded-lg overflow-hidden shrink-0 border border-slate-200 dark:border-slate-800">
                                  {isVideoUrl(selectedIssue.imageUrl) ? (
                                    <video
                                      src={selectedIssue.imageUrl}
                                      className="w-full h-full object-cover"
                                      muted
                                      playsInline
                                      preload="metadata"
                                    />
                                  ) : (
                                    <img src={selectedIssue.imageUrl} alt="Complaint detail" className="w-full h-full object-cover" />
                                  )}
                                </div>
                              )}
                              <div>
                                <span className="text-[10px] text-purple-600 dark:text-purple-400 font-bold uppercase tracking-wider block">Currently Inspecting Case</span>
                                <h3 className="font-bold font-display text-md text-slate-800 dark:text-slate-100">{selectedIssue.title}</h3>
                                <p className="text-[11px] text-slate-400 dark:text-slate-500 mt-1">
                                  Reported At: {new Date(selectedIssue.reportedAt).toLocaleString()} | Reporter: {selectedIssue.reporterName}
                                </p>
                              </div>
                            </div>
                            <button
                              onClick={() => setSelectedIssue(null)}
                              className="p-1.5 bg-slate-100 dark:bg-zinc-800 hover:bg-slate-200 dark:hover:bg-zinc-700 rounded-xl text-slate-500 dark:text-slate-400 transition-colors border border-slate-200/60 dark:border-zinc-700/60 shrink-0"
                              title="Close Inspection Console"
                            >
                              <X size={16} />
                            </button>
                          </div>

                          {/* Accordion panel/Stack controls */}
                          <div className="space-y-5">
                            
                            {/* Controller Block 1: Lifecycle State Progression */}
                            <div className="bg-slate-50 dark:bg-slate-950 p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-3">
                              <h4 className="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wide flex items-center gap-1.5">
                                <Activity size={12} className="text-purple-500" />
                                1. Lifecycle State Progression Console
                              </h4>
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                                <div>
                                  <label className="block text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase mb-1">Update Status Phase</label>
                                  <select
                                    value={adminSelectedStatus}
                                    onChange={(e) => setAdminSelectedStatus(e.target.value as any)}
                                    className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg text-xs px-3 py-2 outline-none focus:ring-1 focus:ring-purple-500"
                                  >
                                    <option value="Reported">Reported</option>
                                    <option value="Under Verification">Under Verification</option>
                                    <option value="Assigned">Assigned (Allocated)</option>
                                    <option value="In Progress">In Progress</option>
                                    <option value="Resolved">Resolved (Completed)</option>
                                  </select>
                                </div>
                                <div>
                                  <label className="block text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase mb-1">Administrative log note</label>
                                  <textarea
                                    rows={1}
                                    value={adminStatusNotes}
                                    onChange={(e) => setAdminStatusNotes(e.target.value)}
                                    placeholder="Enter details (e.g., dispatching road repair crew)..."
                                    className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg text-xs px-3 py-2 outline-none focus:ring-1 focus:ring-purple-500"
                                  />
                                </div>
                              </div>
                              <button
                                onClick={() => updateIssueStatusAdmin(selectedIssue.id)}
                                disabled={updatingStatusId === selectedIssue.id}
                                className="w-full py-2 bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs rounded-lg flex items-center justify-center gap-1.5 transition-all shadow"
                              >
                                {updatingStatusId === selectedIssue.id ? (
                                  <>
                                    <Loader2 size={12} className="animate-spin" />
                                    <span>Syncing lifecycle...</span>
                                  </>
                                ) : (
                                  <>
                                    <CheckCircle2 size={12} />
                                    <span>Save Lifecycle Status & Notes Log</span>
                                  </>
                                )}
                              </button>
                            </div>

                            {/* Controller Block 2: Field Crew Dispatch Work Order */}
                            <div className="bg-slate-50 dark:bg-slate-950 p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-3">
                              <h4 className="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wide flex items-center gap-1.5">
                                <Wrench size={12} className="text-yellow-500" />
                                2. Municipal Work Order Dispatch Engine
                              </h4>
                              <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs">
                                <div className="col-span-2">
                                  <label className="block text-[9px] font-bold text-slate-400 dark:text-slate-500 uppercase mb-0.5">Crew Name</label>
                                  <input
                                    type="text"
                                    value={crewName}
                                    onChange={(e) => setCrewName(e.target.value)}
                                    className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded p-1.5"
                                  />
                                </div>
                                <div>
                                  <label className="block text-[9px] font-bold text-slate-400 dark:text-slate-500 uppercase mb-0.5">Team Size</label>
                                  <input
                                    type="number"
                                    value={crewSize}
                                    onChange={(e) => setCrewSize(parseInt(e.target.value) || 2)}
                                    className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded p-1.5 font-mono"
                                  />
                                </div>
                                <div>
                                  <label className="block text-[9px] font-bold text-slate-400 dark:text-slate-500 uppercase mb-0.5">Target Finish</label>
                                  <input
                                    type="date"
                                    value={crewTargetDate}
                                    onChange={(e) => setCrewTargetDate(e.target.value)}
                                    className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded p-1"
                                  />
                                </div>
                              </div>
                              <div>
                                <label className="block text-[9px] font-bold text-slate-400 dark:text-slate-500 uppercase mb-0.5">Crew Instructions</label>
                                <textarea
                                  rows={2}
                                  value={crewNotes}
                                  onChange={(e) => setCrewNotes(e.target.value)}
                                  className="w-full text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded p-1.5"
                                />
                              </div>
                              <button
                                onClick={() => dispatchWorkOrder(selectedIssue.id)}
                                disabled={updatingStatusId === selectedIssue.id}
                                className="w-full py-2.5 bg-violet-600 hover:bg-violet-700 text-white font-bold text-xs rounded-lg flex items-center justify-center gap-1.5 transition-all shadow-sm"
                              >
                                <Wrench size={12} />
                                <span>Issue Field Crew Dispatch Work Order</span>
                              </button>
                            </div>

                            {/* Controller Block 3: Moderation & Abuse Control */}
                            <div className="bg-slate-50 dark:bg-slate-950 p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-3">
                              <h4 className="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wide flex items-center gap-1.5">
                                <MessageSquare size={12} className="text-orange-500" />
                                3. Parameters Moderation & Spam Filter
                              </h4>
                              <div className="grid grid-cols-3 gap-2">
                                <div>
                                  <label className="block text-[9px] font-bold text-slate-400 dark:text-slate-500 uppercase mb-0.5">Report Severity</label>
                                  <select
                                    value={selectedIssue.severity}
                                    onChange={(e) => moderateIssueParameters(selectedIssue.id, e.target.value, selectedIssue.urgencyScore, selectedIssue.duplicateOf)}
                                    className="w-full text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded p-1.5 outline-none"
                                  >
                                    <option value="Low">Low</option>
                                    <option value="Medium">Medium</option>
                                    <option value="High">High</option>
                                    <option value="Critical">Critical</option>
                                  </select>
                                </div>
                                <div>
                                  <label className="block text-[9px] font-bold text-slate-400 dark:text-slate-500 uppercase mb-0.5">Urgency Score (1-100)</label>
                                  <input
                                    type="number"
                                    min="1"
                                    max="100"
                                    value={selectedIssue.urgencyScore}
                                    onChange={(e) => moderateIssueParameters(selectedIssue.id, selectedIssue.severity, parseInt(e.target.value) || 50, selectedIssue.duplicateOf)}
                                    className="w-full text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded p-1.5 font-mono"
                                  />
                                </div>
                                <div>
                                  <label className="block text-[9px] font-bold text-slate-400 dark:text-slate-500 uppercase mb-0.5">Mark as Duplicate of ID</label>
                                  <input
                                    type="text"
                                    placeholder="Issue ID"
                                    value={selectedIssue.duplicateOf || ""}
                                    onChange={(e) => moderateIssueParameters(selectedIssue.id, selectedIssue.severity, selectedIssue.urgencyScore, e.target.value || undefined)}
                                    className="w-full text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded p-1.5 font-mono"
                                  />
                                </div>
                              </div>

                              {/* Comment Moderation sub list */}
                              <div className="mt-3">
                                <span className="block text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase mb-1">Moderate User Discussion Comments</span>
                                {selectedIssue.comments && selectedIssue.comments.length > 0 ? (
                                  <div className="space-y-1.5 max-h-32 overflow-y-auto">
                                    {selectedIssue.comments.map(c => (
                                      <div key={c.id} className="flex items-center justify-between p-2 bg-white dark:bg-slate-900 rounded border border-slate-100 dark:border-slate-800 text-[11px]">
                                        <div className="truncate pr-2">
                                          <strong className="text-slate-700 dark:text-slate-300 font-bold">{c.userName}:</strong>
                                          <span className="text-slate-500 dark:text-slate-400 ml-1 italic">"{c.text}"</span>
                                        </div>
                                        <button
                                          onClick={() => deleteCommentAdmin(selectedIssue.id, c.id)}
                                          className="p-1 hover:bg-rose-50 dark:hover:bg-rose-950/30 text-rose-600 rounded transition-colors"
                                          title="Remove inappropriate comment"
                                        >
                                          <Trash2 size={12} />
                                        </button>
                                      </div>
                                    ))}
                                  </div>
                                ) : (
                                  <p className="text-[10px] text-slate-400 italic">No community comments have been registered under this report.</p>
                                )}
                              </div>
                            </div>

                            {/* Controller Block 4: Permanent database deletion */}
                            <div className="bg-red-50/50 dark:bg-red-950/10 p-4 rounded-xl border border-red-200/50 dark:border-red-900/40">
                              <h4 className="text-xs font-bold text-red-700 dark:text-red-400 uppercase tracking-wide flex items-center gap-1.5">
                                <AlertTriangle size={12} />
                                4. Database Administration Command (Danger Zone)
                              </h4>
                              <p className="text-[10px] text-red-600/80 dark:text-red-400/80 mt-1 mb-2">
                                Clean up spam duplicates or inappropriate complaints by wiping this complaint record permanently from the live database.
                              </p>
                              <button
                                onClick={() => deleteIssueAdmin(selectedIssue.id)}
                                className="w-full py-2 bg-red-600 hover:bg-red-700 text-white font-bold text-xs rounded-lg flex items-center justify-center gap-1.5 transition-all shadow"
                              >
                                <Trash2 size={12} />
                                <span>Permanently Delete Citizen Complaint Report</span>
                              </button>
                            </div>

                          </div>
                        </div>
                      ) : (
                        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-12 text-center text-slate-400">
                          <Settings size={48} className="mx-auto mb-3 text-slate-300 dark:text-slate-700 animate-spin" />
                          <h4 className="font-bold text-slate-500">Lifecycle & Dispatch Operations console</h4>
                          <p className="text-xs mt-1 max-w-sm mx-auto">
                            Select any active citizen complaint from the left-hand column to dispatch repair crews, moderate comments, edit severity parameters, or advance status.
                          </p>
                        </div>
                      )}
                    </div>

                  </div>
                )}

                {/* Sub-tab 2: Citizen Registry & Badge Management */}
                {adminSubTab === "citizens" && (
                  <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
                    
                    {/* Citizens left sidebar directory */}
                    <div className="xl:col-span-5 space-y-4">
                      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 shadow-sm space-y-3">
                        <div className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest">
                          Citizen Directory search
                        </div>
                        <input
                          type="text"
                          placeholder="Search citizens by name or email..."
                          value={adminUserSearch}
                          onChange={(e) => setAdminUserSearch(e.target.value)}
                          className="w-full text-xs px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 focus:outline-none focus:ring-1 focus:ring-purple-500"
                        />
                      </div>

                      <div className="space-y-2 max-h-[550px] overflow-y-auto pr-1">
                        {adminUsers
                          .filter(u => u.name.toLowerCase().includes(adminUserSearch.toLowerCase()) || u.email.toLowerCase().includes(adminUserSearch.toLowerCase()))
                          .map(u => {
                            const isSel = selectedAdminUser?.id === u.id;
                            return (
                              <div
                                key={u.id}
                                className={`p-3.5 rounded-xl border bg-white dark:bg-slate-900 cursor-pointer shadow-sm transition-all flex items-center justify-between ${
                                  isSel
                                    ? "border-purple-600 ring-2 ring-purple-100 dark:ring-purple-950/30"
                                    : "border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700"
                                }`}
                                onClick={() => setSelectedAdminUser(u)}
                              >
                                <div className="flex items-center gap-2.5 min-w-0">
                                  <div className="w-10 h-10 rounded-full overflow-hidden shrink-0 border border-slate-200 dark:border-slate-800">
                                    <img src={u.avatarUrl || BLANK_AVATAR} alt="User profile" className="w-full h-full object-cover" />
                                  </div>
                                  <div className="min-w-0">
                                    <div className="font-bold text-xs text-slate-800 dark:text-slate-100 flex items-center gap-1">
                                      {u.name}
                                      {u.role === "admin" && <Shield size={10} className="text-purple-600" />}
                                    </div>
                                    <div className="text-[10px] text-slate-400 truncate">{u.email}</div>
                                  </div>
                                </div>
                                
                                <div className="text-right">
                                  <div className="font-mono font-bold text-xs text-purple-600 dark:text-purple-400">{u.points} pts</div>
                                  <div className="text-[9px] font-semibold text-emerald-500 uppercase tracking-widest">{u.reputationScore}% Rep</div>
                                </div>
                              </div>
                            );
                          })}
                      </div>
                    </div>

                    {/* Citizen detail panel */}
                    <div className="xl:col-span-7">
                      {selectedAdminUser ? (
                        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-md space-y-6">
                          
                          {/* User card header */}
                          <div className="flex items-center gap-4 pb-4 border-b border-slate-100 dark:border-slate-800">
                            <div className="w-16 h-16 rounded-full overflow-hidden border border-slate-200 dark:border-slate-800 shrink-0">
                              <img src={selectedAdminUser.avatarUrl || BLANK_AVATAR} alt="Avatar" className="w-full h-full object-cover" />
                            </div>
                            <div>
                              <div className="flex items-center gap-1.5">
                                <h3 className="font-display font-extrabold text-lg text-slate-800 dark:text-slate-100">{selectedAdminUser.name}</h3>
                                <span className={`text-[9px] uppercase tracking-wider font-bold px-2 py-0.5 rounded-full ${
                                  selectedAdminUser.role === "admin" ? "bg-purple-100 text-purple-800 dark:bg-purple-950 dark:text-purple-400" : "bg-yellow-400/20 text-yellow-700 dark:bg-yellow-950 dark:text-yellow-400 border border-yellow-200/50 dark:border-yellow-900/50"
                                }`}>
                                  {selectedAdminUser.role}
                                </span>
                              </div>
                              <p className="text-xs text-slate-400 font-mono mt-0.5">{selectedAdminUser.email}</p>
                              <div className="flex items-center gap-3 mt-1.5 text-[10px] text-slate-400 font-semibold uppercase">
                                <span>Reported: <strong className="text-slate-700 dark:text-slate-300 font-mono">{selectedAdminUser.reportsCount || 0}</strong></span>
                                <span>Verified: <strong className="text-slate-700 dark:text-slate-300 font-mono">{selectedAdminUser.verificationsCount || 0}</strong></span>
                                <span>Member: <strong className="font-mono">{new Date(selectedAdminUser.createdAt).toLocaleDateString()}</strong></span>
                              </div>
                            </div>
                          </div>

                          {/* Scores & Badges Modifier Controls */}
                          <div className="space-y-6">
                            
                            {/* Points adjusting */}
                            <div className="p-4 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl space-y-3">
                              <h4 className="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider">
                                Civic Reputation Points & Score Modifiers
                              </h4>
                              
                              <div className="grid grid-cols-2 gap-4">
                                <div>
                                  <span className="block text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase mb-1">Adjust Points</span>
                                  <div className="flex gap-2">
                                    <button
                                      onClick={() => adjustUserPoints(selectedAdminUser.id, selectedAdminUser.points + 50, selectedAdminUser.reputationScore)}
                                      className="flex-1 py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 dark:bg-emerald-950/20 dark:hover:bg-emerald-900/30 dark:text-emerald-400 text-xs font-bold rounded-lg transition-all"
                                    >
                                      +50 Reward pts
                                    </button>
                                    <button
                                      onClick={() => adjustUserPoints(selectedAdminUser.id, Math.max(0, selectedAdminUser.points - 50), selectedAdminUser.reputationScore)}
                                      className="flex-1 py-2 bg-rose-50 hover:bg-rose-100 text-rose-700 dark:bg-rose-950/20 dark:hover:bg-rose-900/30 dark:text-rose-400 text-xs font-bold rounded-lg transition-all"
                                    >
                                      -50 Penalty pts
                                    </button>
                                  </div>
                                </div>
                                <div>
                                  <span className="block text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase mb-1">
                                    Reputation Rating: <strong className="text-purple-600 font-mono">{selectedAdminUser.reputationScore}%</strong>
                                  </span>
                                  <input
                                    type="range"
                                    min="0"
                                    max="100"
                                    value={selectedAdminUser.reputationScore}
                                    onChange={(e) => adjustUserPoints(selectedAdminUser.id, selectedAdminUser.points, parseInt(e.target.value))}
                                    className="w-full accent-purple-600 cursor-pointer"
                                  />
                                </div>
                              </div>
                            </div>

                            {/* Badge management list */}
                            <div className="p-4 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl space-y-3">
                              <h4 className="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider">
                                Award / Revoke Civic Badges
                              </h4>
                              <p className="text-[10px] text-slate-400">
                                Toggle civic decorations on this citizen's public file to appreciate exceptional neighborhood monitoring.
                              </p>

                              <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                                {[
                                  { id: "watcher", name: "Civic Watcher", color: "bg-yellow-400/20 text-yellow-700 dark:bg-yellow-950 dark:text-yellow-300 border border-yellow-200/50 dark:border-yellow-900/50" },
                                  { id: "hero", name: "Neighborhood Hero", color: "bg-purple-100 text-purple-800 dark:bg-purple-950 dark:text-purple-300" },
                                  { id: "guardian", name: "Street Guardian", color: "bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300" },
                                  { id: "maker", name: "City Maker", color: "bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300" }
                                ].map(badge => {
                                  const hasBadge = selectedAdminUser.badges.includes(badge.id);
                                  return (
                                    <button
                                      key={badge.id}
                                      onClick={() => toggleUserBadge(selectedAdminUser.id, badge.id, hasBadge ? "revoke" : "award")}
                                      className={`p-2.5 rounded-lg border text-left text-xs font-semibold flex items-center justify-between transition-all ${
                                        hasBadge
                                          ? "bg-purple-100/60 dark:bg-purple-950/40 border-purple-300 dark:border-purple-800 text-purple-900 dark:text-purple-300 font-bold"
                                          : "bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:bg-slate-50 text-slate-500"
                                      }`}
                                    >
                                      <span>{badge.name}</span>
                                      {hasBadge ? (
                                        <span className="text-[9px] bg-purple-500 text-white font-mono font-bold px-1.5 py-0.5 rounded uppercase">✓ Active</span>
                                      ) : (
                                        <span className="text-[9px] bg-slate-100 dark:bg-slate-800 text-slate-400 px-1.5 py-0.5 rounded uppercase">Inactive</span>
                                      )}
                                    </button>
                                  );
                                })}
                              </div>
                            </div>

                          </div>
                        </div>
                      ) : (
                        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-12 text-center text-slate-400">
                          <Users size={48} className="mx-auto mb-3 text-slate-300 dark:text-slate-700" />
                          <h4 className="font-bold text-slate-500">Citizen Profile Management</h4>
                          <p className="text-xs mt-1 max-w-sm mx-auto">
                            Select any citizen from the directory roster on the left to reward civic points, adjust reputation score, or award honorary badges.
                          </p>
                        </div>
                      )}
                    </div>

                  </div>
                )}

                {/* Sub-tab 3: Municipal Analytics Overview */}
                {adminSubTab === "insights" && (
                  <div className="space-y-6">
                    
                    {/* Stat summaries grid */}
                    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                      
                      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm">
                        <span className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest block">Total Reports</span>
                        <div className="flex items-baseline gap-2 mt-1">
                          <span className="text-3xl font-display font-black text-slate-800 dark:text-slate-100">{issues.length}</span>
                          <span className="text-[10px] text-emerald-500 font-bold">100% database active</span>
                        </div>
                      </div>

                      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm">
                        <span className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest block">Resolution Rate</span>
                        <div className="flex items-baseline gap-2 mt-1">
                          <span className="text-3xl font-display font-black text-slate-800 dark:text-slate-100">
                            {issues.length > 0 ? Math.round((issues.filter(i => i.status === "Resolved").length / issues.length) * 100) : 0}%
                          </span>
                          <span className="text-[10px] text-slate-400 font-bold">
                            {issues.filter(i => i.status === "Resolved").length} of {issues.length} cases
                          </span>
                        </div>
                      </div>

                      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm">
                        <span className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest block">Under Verification</span>
                        <div className="flex items-baseline gap-2 mt-1">
                          <span className="text-3xl font-display font-black text-slate-800 dark:text-slate-100">
                            {issues.filter(i => i.status === "Under Verification" || i.status === "Reported").length}
                          </span>
                          <span className="text-[10px] text-amber-500 font-bold">Awaiting dispatch reviews</span>
                        </div>
                      </div>

                      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm">
                        <span className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest block">Critical Hazard Ratio</span>
                        <div className="flex items-baseline gap-2 mt-1">
                          <span className="text-3xl font-display font-black text-rose-600 dark:text-rose-400">
                            {issues.length > 0 ? Math.round((issues.filter(i => i.severity === "Critical" || i.severity === "High").length / issues.length) * 100) : 0}%
                          </span>
                          <span className="text-[10px] text-rose-500 font-bold">Action mandated</span>
                        </div>
                      </div>

                    </div>

                    {/* Breakdown bars details */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      
                      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm space-y-4">
                        <h4 className="font-display font-bold text-sm text-slate-700 dark:text-slate-300 uppercase tracking-wider">
                          Incidents Category Breakdown
                        </h4>
                        
                        <div className="space-y-3 text-xs">
                          {[
                            { label: "Potholes & Resurfacing", cat: "potholes" },
                            { label: "Water Leakages & Drainage", cat: "water_leakages" },
                            { label: "Garbage & Illegal Dumping", cat: "garbage_accumulation" },
                            { label: "Broken Streetlighting", cat: "broken_streetlights" },
                            { label: "Damaged Infrastructure", cat: "damaged_infrastructure" },
                            { label: "Road & Traffic Hazards", cat: "road_hazards" }
                          ].map(item => {
                            const count = issues.filter(i => i.category === item.cat).length;
                            const pct = issues.length > 0 ? Math.round((count / issues.length) * 100) : 0;
                            return (
                              <div key={item.cat} className="space-y-1">
                                <div className="flex justify-between text-[11px] font-semibold text-slate-600 dark:text-slate-400">
                                  <span>{item.label}</span>
                                  <span className="font-mono">{count} complaints ({pct}%)</span>
                                </div>
                                <div className="w-full bg-slate-100 dark:bg-slate-800 rounded-full h-2 overflow-hidden">
                                  <div className="bg-purple-600 h-full rounded-full transition-all duration-500" style={{ width: `${pct}%` }}></div>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>

                      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm space-y-4">
                        <h4 className="font-display font-bold text-sm text-slate-700 dark:text-slate-300 uppercase tracking-wider">
                          Civic Contribution Contributors Leaders
                        </h4>
                        
                        <div className="space-y-3.5">
                          {leaderboard.slice(0, 5).map((lead, idx) => (
                            <div key={lead.userId} className="flex items-center justify-between text-xs border-b border-slate-100 dark:border-slate-800 pb-2 last:border-0 last:pb-0">
                              <div className="flex items-center gap-2.5">
                                <span className="font-mono text-slate-400 font-bold w-4">#{idx+1}</span>
                                <div className="w-8 h-8 rounded-full overflow-hidden border">
                                  <img src={lead.avatar} alt={lead.name} className="w-full h-full object-cover" />
                                </div>
                                <div>
                                  <span className="font-bold text-slate-800 dark:text-slate-200">{lead.name}</span>
                                  <span className="block text-[10px] text-slate-400">Reputation: {lead.reputation}%</span>
                                </div>
                              </div>
                              <div className="text-right">
                                <span className="font-mono font-bold text-purple-600 dark:text-purple-400">{lead.points} pts</span>
                                <span className="block text-[9px] text-slate-400 font-bold uppercase">{lead.reportsCount} reports filed</span>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>

                    </div>

                  </div>
                )}

                {/* Sub-tab 4: Firebase Database Explorer */}
                {adminSubTab === "database" && (
                  <div className="space-y-6 animate-fade-in">
                    
                    {/* Direct Console Navigation Links */}
                    <div className="bg-slate-50 dark:bg-zinc-950 border border-slate-200 dark:border-zinc-800 rounded-3xl p-6 shadow-sm">
                      <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
                        <div className="space-y-1.5">
                          <h4 className="font-display font-black text-slate-800 dark:text-white uppercase tracking-tight text-sm flex items-center gap-1.5">
                            <Database size={16} className="text-violet-500" />
                            Official Google Cloud Firestore Console
                          </h4>
                          <p className="text-xs text-zinc-500 dark:text-zinc-400 max-w-3xl font-bold">
                            Since your database is provisioned natively in Google Cloud (Project: <span className="font-mono font-black text-violet-600 dark:text-violet-400">soy-freehold-r2t1j</span>, Database ID: <span className="font-mono font-black text-violet-600 dark:text-violet-400">ai-studio-streetpulse-d65cfe66-f410-4ed8-bbc2-12edb6e45ffb</span>), you can access the official production database management panels using the direct navigation links below.
                          </p>
                        </div>
                        <div className="flex flex-wrap gap-2 shrink-0">
                          <a
                            href="https://console.firebase.google.com/project/soy-freehold-r2t1j/firestore/databases/ai-studio-streetpulse-d65cfe66-f410-4ed8-bbc2-12edb6e45ffb/data"
                            target="_blank"
                            rel="noopener noreferrer"
                            className="px-4 py-2 bg-gradient-to-r from-orange-500 to-amber-500 text-white font-bold text-xs rounded-xl hover:opacity-90 transition-all flex items-center gap-1.5 shadow-md shadow-orange-500/10"
                          >
                            Firebase Firestore Console
                            <ChevronRight size={12} />
                          </a>
                          <a
                            href="https://console.cloud.google.com/firestore/databases/ai-studio-streetpulse-d65cfe66-f410-4ed8-bbc2-12edb6e45ffb/data/panel?project=soy-freehold-r2t1j"
                            target="_blank"
                            rel="noopener noreferrer"
                            className="px-4 py-2 bg-slate-800 dark:bg-zinc-800 text-white font-bold text-xs rounded-xl hover:bg-slate-750 transition-all flex items-center gap-1.5 border border-zinc-700 shadow-sm"
                          >
                            Google Cloud Console
                            <ChevronRight size={12} />
                          </a>
                        </div>
                      </div>
                    </div>

                    {/* Database Seeder & Controls */}
                    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                      
                      {/* Left Pane: Collection Switcher & Seeder */}
                      <div className="lg:col-span-4 space-y-4">
                        
                        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm space-y-4">
                          <div className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest">
                            Collections Directory
                          </div>
                          <div className="space-y-1.5">
                            {[
                              { id: "issues", label: "Issues Collection", count: issues.length, color: "text-amber-500 bg-amber-50 dark:bg-amber-950/20" },
                              { id: "users", label: "Users Collection", count: adminUsers.length, color: "text-blue-500 bg-blue-50 dark:bg-blue-950/20" },
                              { id: "notifications", label: "Notifications Collection", count: dbAllNotifications.length, color: "text-violet-500 bg-violet-50 dark:bg-violet-950/20" }
                            ].map(col => (
                              <button
                                key={col.id}
                                onClick={() => {
                                  setDbCollection(col.id as any);
                                  setDbSelectedDocumentId(null);
                                }}
                                className={`w-full p-3 rounded-xl border text-left flex items-center justify-between transition-all ${
                                  dbCollection === col.id
                                    ? "bg-violet-600 border-violet-600 text-white font-bold shadow-md"
                                    : "bg-slate-50 dark:bg-slate-950 border-slate-150 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-900 text-slate-700 dark:text-slate-300"
                                }`}
                              >
                                <div className="flex items-center gap-2">
                                  <Database size={14} />
                                  <span className="text-xs uppercase tracking-tight font-bold">{col.label}</span>
                                </div>
                                <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-full ${
                                  dbCollection === col.id ? "bg-white/20 text-white" : col.color
                                }`}>
                                  {col.count} docs
                                </span>
                              </button>
                            ))}
                          </div>
                        </div>

                        {/* Database Seed/Restore Module */}
                        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm space-y-4">
                          <div className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest">
                            Database Seed & Reset Tools
                          </div>
                          <p className="text-xs text-slate-500 font-semibold">
                            Restore default datasets in your Firebase database instantly. This will seed clean, realistic mock profiles, notifications, and reports to verify app performance.
                          </p>
                          <button
                            onClick={handleSeedDatabase}
                            disabled={dbIsSyncing}
                            className="w-full py-2.5 bg-rose-600 hover:bg-rose-700 disabled:bg-rose-400 text-white font-bold text-xs uppercase tracking-wider rounded-xl transition-all flex items-center justify-center gap-1.5 shadow-md shadow-rose-500/10 cursor-pointer"
                          >
                            {dbIsSyncing ? (
                              <>
                                <Loader2 size={13} className="animate-spin" />
                                Syncing defaults...
                              </>
                            ) : (
                              <>
                                <RefreshCw size={13} />
                                Seed & Reset Firestore
                              </>
                            )}
                          </button>
                        </div>

                        {/* Add Broadcast Alert Notification */}
                        {dbCollection === "notifications" && (
                          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm space-y-3.5">
                            <div className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest">
                              Dispatch Live Notification
                            </div>
                            <form onSubmit={handleCreateDbNotification} className="space-y-3">
                              <div className="space-y-1">
                                <label className="text-[10px] font-bold uppercase text-slate-400">Target User</label>
                                <select
                                  value={dbCustomNotificationUserId}
                                  onChange={(e) => setDbCustomNotificationUserId(e.target.value)}
                                  className="w-full text-xs p-2 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 outline-none font-bold"
                                >
                                  <option value="">Select Target Citizen</option>
                                  {adminUsers.map(u => (
                                    <option key={u.id} value={u.id}>{u.name} ({u.role})</option>
                                  ))}
                                </select>
                              </div>
                              <div className="space-y-1">
                                <label className="text-[10px] font-bold uppercase text-slate-400">Alert Message</label>
                                <textarea
                                  placeholder="Type broadcast alert text..."
                                  value={dbCustomNotificationText}
                                  onChange={(e) => setDbCustomNotificationText(e.target.value)}
                                  className="w-full text-xs p-2 h-16 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 outline-none resize-none focus:ring-1 focus:ring-violet-500 font-semibold"
                                />
                              </div>
                              <button
                                type="submit"
                                className="w-full py-2 bg-violet-600 hover:bg-violet-700 text-white font-bold text-xs rounded-lg transition-all cursor-pointer"
                              >
                                Send & Write Doc
                              </button>
                            </form>
                          </div>
                        )}

                      </div>

                      {/* Right Pane: Table List of Documents & Details */}
                      <div className="lg:col-span-8 space-y-4">
                        
                        {/* Search & Document list */}
                        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm space-y-4">
                          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                            <div className="space-y-0.5">
                              <h4 className="font-bold text-slate-800 dark:text-white uppercase text-xs tracking-wide">
                                Documents in `{dbCollection}` Collection
                              </h4>
                              <p className="text-[10px] text-slate-400 font-mono font-bold">
                                Live Firestore synchronized view
                              </p>
                            </div>
                            <input
                              type="text"
                              placeholder="Search doc properties..."
                              value={dbSearchQuery}
                              onChange={(e) => setDbSearchQuery(e.target.value)}
                              className="text-xs px-3 py-1.5 w-full sm:w-64 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 outline-none focus:ring-1 focus:ring-violet-500 font-bold"
                            />
                          </div>

                          <div className="overflow-x-auto max-h-[500px]">
                            <table className="w-full text-left text-xs border-collapse">
                              <thead>
                                <tr className="border-b border-slate-100 dark:border-zinc-850 text-slate-400 uppercase tracking-wider text-[10px] font-bold">
                                  <th className="py-2.5 px-3">Document ID</th>
                                  <th className="py-2.5 px-3">Main Attribute</th>
                                  <th className="py-2.5 px-3">Status/Detail</th>
                                  <th className="py-2.5 px-3 text-right">Actions</th>
                                </tr>
                              </thead>
                              <tbody>
                                {(() => {
                                  // Get docs
                                  const q = dbSearchQuery.toLowerCase();
                                  let list: any[] = [];
                                  if (dbCollection === "issues") {
                                    list = issues.filter(i => 
                                      i.id.toLowerCase().includes(q) || 
                                      i.title.toLowerCase().includes(q) || 
                                      i.category.toLowerCase().includes(q)
                                    );
                                  } else if (dbCollection === "users") {
                                    list = adminUsers.filter(u => 
                                      u.id.toLowerCase().includes(q) || 
                                      u.name.toLowerCase().includes(q) || 
                                      u.email.toLowerCase().includes(q)
                                    );
                                  } else {
                                    list = dbAllNotifications.filter(n => 
                                      n.id.toLowerCase().includes(q) || 
                                      n.userId.toLowerCase().includes(q) || 
                                      n.title.toLowerCase().includes(q) || 
                                      n.text.toLowerCase().includes(q)
                                    );
                                  }

                                  if (list.length === 0) {
                                    return (
                                      <tr>
                                        <td colSpan={4} className="py-8 text-center text-slate-400 font-bold">
                                          No documents found matching search query in this collection.
                                        </td>
                                      </tr>
                                    );
                                  }
                                  return list.map(docItem => {
                                    const isSelected = dbSelectedDocumentId === docItem.id;
                                    
                                    // Custom visual properties per collection
                                    let attr = "";
                                    let extra = "";
                                    if (dbCollection === "issues") {
                                      const issue = docItem as Issue;
                                      attr = issue.title;
                                      extra = issue.status;
                                    } else if (dbCollection === "users") {
                                      const u = docItem as UserProfile;
                                      attr = u.name;
                                      extra = u.role.toUpperCase();
                                    } else {
                                      const n = docItem as Notification;
                                      attr = n.text;
                                      extra = n.read ? "Read" : "Unread";
                                    }

                                    return (
                                      <React.Fragment key={docItem.id}>
                                        <tr
                                          onClick={() => handleSelectDbDocument(docItem)}
                                          className={`border-b border-slate-50 dark:border-zinc-850/50 hover:bg-slate-50 dark:hover:bg-zinc-850/40 cursor-pointer transition-colors ${
                                            isSelected ? "bg-violet-50/50 dark:bg-violet-950/20" : ""
                                          }`}
                                        >
                                          <td className="py-3 px-3 font-mono font-bold text-[10.5px] text-violet-600 dark:text-violet-400">
                                            {docItem.id}
                                          </td>
                                          <td className="py-3 px-3 font-bold text-slate-800 dark:text-slate-200 truncate max-w-[200px]">
                                            {attr}
                                          </td>
                                          <td className="py-3 px-3">
                                            <span className={`text-[9px] font-bold uppercase px-2 py-0.5 rounded-full ${
                                              extra === "Resolved" || extra === "Read" || extra === "ADMIN"
                                                ? "bg-emerald-50 text-emerald-600 dark:bg-emerald-950/20 dark:text-emerald-400 border border-emerald-100 dark:border-emerald-900/30"
                                                : "bg-amber-50 text-amber-600 dark:bg-amber-950/20 dark:text-amber-400 border border-amber-100 dark:border-amber-900/30"
                                            }`}>
                                              {extra}
                                            </span>
                                          </td>
                                          <td className="py-3 px-3 text-right" onClick={(e) => e.stopPropagation()}>
                                            <div className="flex items-center justify-end gap-1.5">
                                              <button
                                                onClick={() => handleSelectDbDocument(docItem)}
                                                className="p-1 hover:bg-slate-100 dark:hover:bg-zinc-850 rounded text-slate-500 cursor-pointer"
                                                title="View / Edit Document"
                                              >
                                                <Eye size={12} />
                                              </button>
                                              {dbCollection === "issues" && (
                                                <button
                                                  onClick={() => deleteIssueAdmin(docItem.id)}
                                                  className="p-1 hover:bg-rose-50 dark:hover:bg-rose-950/30 text-rose-500 rounded cursor-pointer"
                                                  title="Delete Document"
                                                >
                                                  <Trash2 size={12} />
                                                </button>
                                              )}
                                              {dbCollection === "users" && (
                                                <button
                                                  onClick={() => deleteDbUser(docItem.id)}
                                                  className="p-1 hover:bg-rose-50 dark:hover:bg-rose-950/30 text-rose-500 rounded cursor-pointer"
                                                  title="Delete User Document"
                                                >
                                                  <Trash2 size={12} />
                                                </button>
                                              )}
                                              {dbCollection === "notifications" && (
                                                <button
                                                  onClick={() => deleteDbNotification(docItem.id)}
                                                  className="p-1 hover:bg-rose-50 dark:hover:bg-rose-950/30 text-rose-500 rounded cursor-pointer"
                                                  title="Delete Document"
                                                >
                                                  <Trash2 size={12} />
                                                </button>
                                              )}
                                            </div>
                                          </td>
                                        </tr>
                                        
                                        {/* Expandable JSON & Document Editor */}
                                        {isSelected && (
                                          <tr>
                                            <td colSpan={4} className="bg-slate-50 dark:bg-zinc-950 p-5 border-b border-slate-100 dark:border-zinc-850">
                                              <div className="space-y-4 text-left">
                                                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-200 dark:border-zinc-850 pb-2.5">
                                                  <div className="flex items-center gap-1.5">
                                                    <button
                                                      type="button"
                                                      onClick={() => setDbEditMode("raw")}
                                                      className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                                                        dbEditMode === "raw"
                                                          ? "bg-violet-600 text-white shadow-sm"
                                                          : "text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-zinc-850"
                                                      }`}
                                                    >
                                                      Raw JSON
                                                    </button>
                                                    <button
                                                      type="button"
                                                      onClick={() => {
                                                        setDbEditMode("form");
                                                        setDbEditingFields({ ...docItem });
                                                      }}
                                                      className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                                                        dbEditMode === "form"
                                                          ? "bg-violet-600 text-white shadow-sm"
                                                          : "text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-zinc-850"
                                                      }`}
                                                    >
                                                      Form Editor
                                                    </button>
                                                    <button
                                                      type="button"
                                                      onClick={() => {
                                                        setDbEditMode("json-edit");
                                                        setDbEditingRawJson(JSON.stringify(docItem, null, 2));
                                                      }}
                                                      className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                                                        dbEditMode === "json-edit"
                                                          ? "bg-violet-600 text-white shadow-sm"
                                                          : "text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-zinc-850"
                                                      }`}
                                                    >
                                                      Advanced JSON Writer
                                                    </button>
                                                  </div>
                                                  <span className="text-[10px] bg-violet-50 dark:bg-violet-950/30 text-violet-600 dark:text-violet-400 px-2.5 py-1 rounded-md font-bold font-mono border border-violet-100 dark:border-violet-900/20">
                                                    Path: /{dbCollection}/{docItem.id}
                                                  </span>
                                                </div>

                                                {/* Tab 1: Read-only Raw Pretty JSON */}
                                                {dbEditMode === "raw" && (
                                                  <div className="space-y-1">
                                                    <pre className="text-[10.5px] font-mono leading-relaxed bg-white dark:bg-zinc-900 p-3.5 rounded-xl border border-slate-200 dark:border-zinc-850 max-h-72 overflow-y-auto text-slate-700 dark:text-slate-300 shadow-inner">
                                                      {JSON.stringify(docItem, null, 2)}
                                                    </pre>
                                                  </div>
                                                )}

                                                {/* Tab 2: Quick Form Editor */}
                                                {dbEditMode === "form" && (
                                                  <form
                                                    onSubmit={async (e) => {
                                                      e.preventDefault();
                                                      await updateDbDocument(dbCollection, docItem.id, dbEditingFields);
                                                    }}
                                                    className="space-y-4 text-xs"
                                                  >
                                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                                      {dbCollection === "users" && (
                                                        <>
                                                          <div className="space-y-1">
                                                            <label className="font-bold text-slate-400 uppercase text-[10px]">Display Name</label>
                                                            <input
                                                              type="text"
                                                              value={dbEditingFields.name || ""}
                                                              onChange={(e) => setDbEditingFields({ ...dbEditingFields, name: e.target.value })}
                                                              className="w-full p-2.5 rounded-xl bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-850 font-semibold"
                                                            />
                                                          </div>
                                                          <div className="space-y-1">
                                                            <label className="font-bold text-slate-400 uppercase text-[10px]">Email Address</label>
                                                            <input
                                                              type="email"
                                                              value={dbEditingFields.email || ""}
                                                              onChange={(e) => setDbEditingFields({ ...dbEditingFields, email: e.target.value })}
                                                              className="w-full p-2.5 rounded-xl bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-850 font-semibold"
                                                            />
                                                          </div>
                                                          <div className="space-y-1">
                                                            <label className="font-bold text-slate-400 uppercase text-[10px]">System Role</label>
                                                            <select
                                                              value={dbEditingFields.role || "citizen"}
                                                              onChange={(e) => setDbEditingFields({ ...dbEditingFields, role: e.target.value })}
                                                              className="w-full p-2.5 rounded-xl bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-850 font-semibold outline-none"
                                                            >
                                                              <option value="citizen">Citizen</option>
                                                              <option value="admin">Administrator</option>
                                                            </select>
                                                          </div>
                                                          <div className="space-y-1">
                                                            <label className="font-bold text-slate-400 uppercase text-[10px]">Reputation Points</label>
                                                            <input
                                                              type="number"
                                                              value={dbEditingFields.points ?? 0}
                                                              onChange={(e) => setDbEditingFields({ ...dbEditingFields, points: Number(e.target.value) })}
                                                              className="w-full p-2.5 rounded-xl bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-850 font-semibold"
                                                            />
                                                          </div>
                                                          <div className="space-y-1">
                                                            <label className="font-bold text-slate-400 uppercase text-[10px]">Reputation Score (0-100)</label>
                                                            <input
                                                              type="number"
                                                              min="0"
                                                              max="100"
                                                              value={dbEditingFields.reputationScore ?? 100}
                                                              onChange={(e) => setDbEditingFields({ ...dbEditingFields, reputationScore: Number(e.target.value) })}
                                                              className="w-full p-2.5 rounded-xl bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-850 font-semibold"
                                                            />
                                                          </div>
                                                          <div className="space-y-1">
                                                            <label className="font-bold text-slate-400 uppercase text-[10px]">Reports Filed Count</label>
                                                            <input
                                                              type="number"
                                                              value={dbEditingFields.reportsCount ?? 0}
                                                              onChange={(e) => setDbEditingFields({ ...dbEditingFields, reportsCount: Number(e.target.value) })}
                                                              className="w-full p-2.5 rounded-xl bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-850 font-semibold"
                                                            />
                                                          </div>
                                                          <div className="space-y-1">
                                                            <label className="font-bold text-slate-400 uppercase text-[10px]">Verifications Count</label>
                                                            <input
                                                              type="number"
                                                              value={dbEditingFields.verificationsCount ?? 0}
                                                              onChange={(e) => setDbEditingFields({ ...dbEditingFields, verificationsCount: Number(e.target.value) })}
                                                              className="w-full p-2.5 rounded-xl bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-850 font-semibold"
                                                            />
                                                          </div>
                                                          <div className="space-y-1">
                                                            <label className="font-bold text-slate-400 uppercase text-[10px]">Badges Awarded (Comma-separated)</label>
                                                            <input
                                                              type="text"
                                                              value={Array.isArray(dbEditingFields.badges) ? dbEditingFields.badges.join(", ") : ""}
                                                              onChange={(e) => {
                                                                const badgesArr = e.target.value.split(",").map(b => b.trim()).filter(Boolean);
                                                                setDbEditingFields({ ...dbEditingFields, badges: badgesArr });
                                                              }}
                                                              className="w-full p-2.5 rounded-xl bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-850 font-semibold"
                                                              placeholder="e.g. hero, watcher, guardian"
                                                            />
                                                          </div>
                                                        </>
                                                      )}

                                                      {dbCollection === "issues" && (
                                                        <>
                                                          <div className="space-y-1 col-span-2">
                                                            <label className="font-bold text-slate-400 uppercase text-[10px]">Issue Title</label>
                                                            <input
                                                              type="text"
                                                              value={dbEditingFields.title || ""}
                                                              onChange={(e) => setDbEditingFields({ ...dbEditingFields, title: e.target.value })}
                                                              className="w-full p-2.5 rounded-xl bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-850 font-semibold"
                                                            />
                                                          </div>
                                                          <div className="space-y-1">
                                                            <label className="font-bold text-slate-400 uppercase text-[10px]">Category</label>
                                                            <input
                                                              type="text"
                                                              value={dbEditingFields.category || ""}
                                                              onChange={(e) => setDbEditingFields({ ...dbEditingFields, category: e.target.value })}
                                                              className="w-full p-2.5 rounded-xl bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-850 font-semibold"
                                                            />
                                                          </div>
                                                          <div className="space-y-1">
                                                            <label className="font-bold text-slate-400 uppercase text-[10px]">Severity Level</label>
                                                            <select
                                                              value={dbEditingFields.severity || "Medium"}
                                                              onChange={(e) => setDbEditingFields({ ...dbEditingFields, severity: e.target.value })}
                                                              className="w-full p-2.5 rounded-xl bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-850 font-semibold outline-none"
                                                            >
                                                              <option value="Low">Low</option>
                                                              <option value="Medium">Medium</option>
                                                              <option value="High">High</option>
                                                              <option value="Critical">Critical</option>
                                                            </select>
                                                          </div>
                                                          <div className="space-y-1">
                                                            <label className="font-bold text-slate-400 uppercase text-[10px]">Issue Status</label>
                                                            <select
                                                              value={dbEditingFields.status || "Reported"}
                                                              onChange={(e) => setDbEditingFields({ ...dbEditingFields, status: e.target.value })}
                                                              className="w-full p-2.5 rounded-xl bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-850 font-semibold outline-none"
                                                            >
                                                              <option value="Reported">Reported</option>
                                                              <option value="Under Verification">Under Verification</option>
                                                              <option value="Assigned">Assigned</option>
                                                              <option value="In Progress">In Progress</option>
                                                              <option value="Resolved">Resolved</option>
                                                            </select>
                                                          </div>
                                                          <div className="space-y-1">
                                                            <label className="font-bold text-slate-400 uppercase text-[10px]">Upvotes</label>
                                                            <input
                                                              type="number"
                                                              value={dbEditingFields.upvotes ?? 0}
                                                              onChange={(e) => setDbEditingFields({ ...dbEditingFields, upvotes: Number(e.target.value) })}
                                                              className="w-full p-2.5 rounded-xl bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-850 font-semibold"
                                                            />
                                                          </div>
                                                          <div className="space-y-1 col-span-2">
                                                            <label className="font-bold text-slate-400 uppercase text-[10px]">Description</label>
                                                            <textarea
                                                              value={dbEditingFields.description || ""}
                                                              onChange={(e) => setDbEditingFields({ ...dbEditingFields, description: e.target.value })}
                                                              className="w-full p-2.5 rounded-xl bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-850 font-semibold h-24 resize-none outline-none"
                                                            />
                                                          </div>
                                                        </>
                                                      )}

                                                      {dbCollection === "notifications" && (
                                                        <>
                                                          <div className="space-y-1 col-span-2">
                                                            <label className="font-bold text-slate-400 uppercase text-[10px]">Notification Title</label>
                                                            <input
                                                              type="text"
                                                              value={dbEditingFields.title || ""}
                                                              onChange={(e) => setDbEditingFields({ ...dbEditingFields, title: e.target.value })}
                                                              className="w-full p-2.5 rounded-xl bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-850 font-semibold"
                                                            />
                                                          </div>
                                                          <div className="space-y-1 col-span-2">
                                                            <label className="font-bold text-slate-400 uppercase text-[10px]">Message Text</label>
                                                            <textarea
                                                              value={dbEditingFields.text || ""}
                                                              onChange={(e) => setDbEditingFields({ ...dbEditingFields, text: e.target.value })}
                                                              className="w-full p-2.5 rounded-xl bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-850 font-semibold h-20 resize-none outline-none"
                                                            />
                                                          </div>
                                                          <div className="space-y-1">
                                                            <label className="font-bold text-slate-400 uppercase text-[10px]">Status</label>
                                                            <select
                                                              value={dbEditingFields.read ? "read" : "unread"}
                                                              onChange={(e) => setDbEditingFields({ ...dbEditingFields, read: e.target.value === "read" })}
                                                              className="w-full p-2.5 rounded-xl bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-850 font-semibold outline-none"
                                                            >
                                                              <option value="unread">Unread / Active</option>
                                                              <option value="read">Read / Dismissed</option>
                                                            </select>
                                                          </div>
                                                        </>
                                                      )}
                                                    </div>

                                                    <div className="flex justify-end gap-2 pt-2 border-t border-slate-100 dark:border-zinc-850">
                                                      <button
                                                        type="button"
                                                        onClick={() => {
                                                          setDbEditingFields({ ...docItem });
                                                        }}
                                                        className="px-4 py-2 bg-slate-100 dark:bg-zinc-800 text-slate-700 dark:text-slate-300 font-bold rounded-lg hover:bg-slate-200 transition-all cursor-pointer"
                                                      >
                                                        Reset Fields
                                                      </button>
                                                      <button
                                                        type="submit"
                                                        className="px-4 py-2 bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-700 hover:to-indigo-700 text-white font-bold rounded-lg shadow-sm shadow-violet-500/10 transition-all flex items-center gap-1.5 cursor-pointer"
                                                      >
                                                        <Save size={13} />
                                                        Save Changes
                                                      </button>
                                                    </div>
                                                  </form>
                                                )}

                                                {/* Tab 3: Advanced JSON Writer */}
                                                {dbEditMode === "json-edit" && (
                                                  <div className="space-y-3 text-xs">
                                                    <div className="space-y-1">
                                                      <label className="font-bold text-slate-400 uppercase text-[10px] block">Raw JSON Document</label>
                                                      <textarea
                                                        value={dbEditingRawJson}
                                                        onChange={(e) => setDbEditingRawJson(e.target.value)}
                                                        className="w-full p-3 font-mono text-[10.5px] leading-relaxed rounded-xl bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-850 h-64 focus:ring-1 focus:ring-violet-500 outline-none"
                                                      />
                                                    </div>
                                                    <div className="flex justify-end gap-2 pt-2 border-t border-slate-100 dark:border-zinc-850">
                                                      <button
                                                        type="button"
                                                        onClick={() => {
                                                          setDbEditingRawJson(JSON.stringify(docItem, null, 2));
                                                        }}
                                                        className="px-4 py-2 bg-slate-100 dark:bg-zinc-800 text-slate-700 dark:text-slate-300 font-bold rounded-lg hover:bg-slate-200 transition-all cursor-pointer"
                                                      >
                                                        Reset JSON
                                                      </button>
                                                      <button
                                                        type="button"
                                                        onClick={async () => {
                                                          try {
                                                            const parsed = JSON.parse(dbEditingRawJson);
                                                            if (parsed.id !== docItem.id) {
                                                              if (!window.confirm("Changing the 'id' field is not allowed or will write as a new document. Force keeping original ID?")) {
                                                                return;
                                                              }
                                                              parsed.id = docItem.id;
                                                            }
                                                            await updateDbDocument(dbCollection, docItem.id, parsed);
                                                          } catch (err: any) {
                                                            alert(`Malformed JSON format: ${err.message}`);
                                                          }
                                                        }}
                                                        className="px-4 py-2 bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-700 hover:to-indigo-700 text-white font-bold rounded-lg shadow-sm shadow-violet-500/10 transition-all flex items-center gap-1.5 cursor-pointer"
                                                      >
                                                        <Save size={13} />
                                                        Validate & Save Document
                                                      </button>
                                                    </div>
                                                  </div>
                                                )}
                                              </div>
                                            </td>
                                          </tr>
                                        )}
                                      </React.Fragment>
                                    );
                                  });
                                })()}
                              </tbody>
                            </table>
                          </div>
                        </div>

                      </div>

                    </div>

                  </div>
                )}

              </div>
            )}

          </div>

        </div>

      </main>

      {/* OFFICIAL REPORT PRINT/MODAL VIEW (ACCESSIBLE TO BOTH CITIZENS AND ADMINS) */}
      {generatedReport && (
        <div className="fixed inset-0 bg-black/85 backdrop-blur-sm z-[100] flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white dark:bg-zinc-900 w-full max-w-4xl rounded-3xl shadow-2xl border border-slate-100 dark:border-zinc-850 max-h-[90vh] flex flex-col overflow-hidden text-black dark:text-white">
            
            {/* Modal header */}
            <div className="p-6 border-b border-slate-100 dark:border-zinc-850 bg-gradient-to-r from-violet-600 to-indigo-600 flex items-center justify-between text-white">
              <div className="flex items-center space-x-2.5">
                <FileText size={20} className="stroke-[2.5px]" />
                <span className="font-display font-bold text-sm tracking-tight uppercase">StreetPulse Official Complaint Report</span>
              </div>
              <button
                onClick={() => setGeneratedReport(null)}
                className="p-1.5 hover:bg-white/10 rounded-lg text-white/80 transition-colors"
              >
                <X size={18} />
              </button>
            </div>

            {/* Document details (Fully Styled printable page) */}
            <div className="flex-1 p-8 overflow-y-auto space-y-6 text-xs text-slate-800 dark:text-slate-200 printable-document">
              
              {/* Official Seal / Header */}
              <div className="flex justify-between items-start border-b border-slate-200 dark:border-slate-800 pb-5">
                <div>
                  <h1 className="text-xl font-display font-black tracking-tight text-slate-950 dark:text-white">STREETPULSE CIVIC ENGAGEMENT PORTAL</h1>
                  <p className="text-[10px] font-mono tracking-widest text-slate-500 uppercase mt-1">MUNICIPAL COMPLAINT INSPECTION UNIT</p>
                </div>
                <div className="text-right font-mono text-[9px] text-slate-400">
                  <p>REPORT ID: {generatedReport.id}</p>
                  <p>GENERATED: {new Date(generatedReport.generatedAt).toLocaleString()}</p>
                </div>
              </div>

              {/* Title info */}
              <div className="space-y-1">
                <h2 className="text-lg font-bold font-display text-slate-800 dark:text-white">{generatedReport.title}</h2>
                <p className="text-slate-500 dark:text-slate-400 font-semibold">{generatedReport.locationInfo}</p>
                <p className="text-[10px] font-mono tracking-wider text-slate-400 mt-1">Audit request initiated by: **{generatedReport.generatedBy}**</p>
              </div>

              {/* Sections details */}
              <div className="space-y-5 divide-y divide-slate-100 dark:divide-slate-800">
                
                <div className="pt-4">
                  <h3 className="text-sm font-bold uppercase tracking-wider text-violet-600 dark:text-violet-400 mb-2">I. Executive Summary</h3>
                  <p className="leading-relaxed whitespace-pre-line text-slate-600 dark:text-slate-300">
                    {generatedReport.summary.replace("EXECUTIVE SUMMARY:", "").trim()}
                  </p>
                </div>

                <div className="pt-4">
                  <h3 className="text-sm font-bold uppercase tracking-wider text-violet-600 dark:text-violet-400 mb-2">II. Technical Hazard Analysis</h3>
                  <p className="leading-relaxed whitespace-pre-line text-slate-600 dark:text-slate-300">
                    {generatedReport.severityAnalysis.replace("TECHNICAL SEVERITY ANALYSIS:", "").trim()}
                  </p>
                </div>

                <div className="pt-4">
                  <h3 className="text-sm font-bold uppercase tracking-wider text-violet-600 dark:text-violet-400 mb-2">III. Recommended Action Plan &amp; Timeline</h3>
                  <p className="leading-relaxed whitespace-pre-line text-slate-600 dark:text-slate-300 font-sans">
                    {generatedReport.recommendedActionPlan.replace("RECOMMENDED MUNICIPAL ACTION PLAN:", "").trim()}
                  </p>
                </div>

              </div>

              {/* Signoff */}
              <div className="pt-10 flex justify-between text-[10px] border-t border-slate-200 dark:border-slate-800">
                <div>
                  <p className="font-bold">Verified Citizen signature</p>
                  <div className="w-32 h-0.5 border-t border-dashed border-slate-400 mt-6"></div>
                  <p className="text-slate-400 mt-1">Digital Auth hash: SHA-256</p>
                </div>
                <div className="text-right">
                  <p className="font-bold">Municipal Inspector Seal</p>
                  <div className="w-32 h-0.5 border-t border-dashed border-slate-400 mt-6 ml-auto"></div>
                  <p className="text-slate-400 mt-1">Status: PENDING AUDIT CLOSE</p>
                </div>
              </div>

            </div>

            {/* Print trigger action */}
            <div className="p-5 border-t border-slate-100 dark:border-zinc-850 bg-slate-50 dark:bg-zinc-950 flex space-x-2 justify-end">
              <button
                onClick={() => setGeneratedReport(null)}
                className="px-4 py-2 bg-white dark:bg-zinc-900 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-zinc-800 font-bold rounded-xl text-xs"
              >
                Close View
              </button>
              <button
                onClick={handlePrintReport}
                className="px-5 py-2 bg-violet-600 text-white font-bold rounded-xl text-xs flex items-center space-x-1.5 hover:bg-violet-700 shadow-md shadow-violet-500/10 transition-all hover:scale-[1.02]"
              >
                <Download size={14} className="stroke-[2.5px]" />
                <span>Download / Print Report</span>
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
